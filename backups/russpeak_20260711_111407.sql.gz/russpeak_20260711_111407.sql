--
-- PostgreSQL database dump
--

\restrict CGvNjIQbSKd1ViCkCRikDUO9ziUziRoUvz8kauZ6Z11Bhnexw6E9K0gSgcgIMLk

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: russpeak
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO russpeak;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: russpeak
--

COMMENT ON SCHEMA public IS '';


--
-- Name: question_type; Type: TYPE; Schema: public; Owner: russpeak
--

CREATE TYPE public.question_type AS ENUM (
    'text',
    'image',
    'video'
);


ALTER TYPE public.question_type OWNER TO russpeak;

--
-- Name: submission_status; Type: TYPE; Schema: public; Owner: russpeak
--

CREATE TYPE public.submission_status AS ENUM (
    'pending',
    'processing',
    'done',
    'failed'
);


ALTER TYPE public.submission_status OWNER TO russpeak;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: russpeak
--

CREATE TYPE public.user_role AS ENUM (
    'teacher',
    'student',
    'admin'
);


ALTER TYPE public.user_role OWNER TO russpeak;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO russpeak;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.app_settings (
    key character varying(64) NOT NULL,
    value text,
    is_secret boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_settings OWNER TO russpeak;

--
-- Name: assignments; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.assignments (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    student_id uuid NOT NULL,
    question_id uuid NOT NULL,
    due_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    group_id uuid
);


ALTER TABLE public.assignments OWNER TO russpeak;

--
-- Name: evaluations; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.evaluations (
    id uuid NOT NULL,
    submission_id uuid NOT NULL,
    fluency_score double precision NOT NULL,
    lexical_score double precision NOT NULL,
    grammar_score double precision NOT NULL,
    pronunciation_score double precision,
    overall_band double precision NOT NULL,
    feedback jsonb,
    corrections jsonb,
    llm_model character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    relevance_score double precision,
    explanation jsonb,
    level_score double precision,
    naturalness_score double precision,
    speech_rate_score double precision,
    intonation_score double precision,
    native_likeness double precision
);


ALTER TABLE public.evaluations OWNER TO russpeak;

--
-- Name: group_members; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.group_members (
    id uuid NOT NULL,
    group_id uuid NOT NULL,
    student_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_members OWNER TO russpeak;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.groups (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    name character varying(128) NOT NULL,
    join_code character varying(12) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.groups OWNER TO russpeak;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    body text,
    link character varying(300),
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO russpeak;

--
-- Name: question_blocks; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.question_blocks (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    name character varying(128) NOT NULL,
    topic character varying(128),
    level character varying(8),
    ru_style character varying(8),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    visibility character varying(8) DEFAULT 'group'::character varying NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    cover_key character varying(512)
);


ALTER TABLE public.question_blocks OWNER TO russpeak;

--
-- Name: questions; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.questions (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    type public.question_type NOT NULL,
    title character varying(255) NOT NULL,
    prompt_text text NOT NULL,
    media_key character varying(512),
    level character varying(8),
    prep_time_sec integer NOT NULL,
    answer_time_limit_sec integer NOT NULL,
    is_published boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    topic character varying(128),
    model_answer_text text,
    is_deleted boolean DEFAULT false NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    block_id uuid,
    ru_style character varying(8),
    instruction_text text,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.questions OWNER TO russpeak;

--
-- Name: review_items; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.review_items (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    question_id uuid NOT NULL,
    weakness_dim character varying(32) NOT NULL,
    interval_index integer DEFAULT 0 NOT NULL,
    due_at timestamp with time zone NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_items OWNER TO russpeak;

--
-- Name: shadowing_phrases; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.shadowing_phrases (
    id uuid NOT NULL,
    created_by uuid,
    text character varying(500) NOT NULL,
    level character varying(16) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shadowing_phrases OWNER TO russpeak;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.submissions (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    question_id uuid,
    audio_key character varying(512) NOT NULL,
    audio_duration_sec double precision,
    status public.submission_status NOT NULL,
    error_message text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    teacher_comment text,
    teacher_band double precision,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    reference_text text,
    assignment_id uuid,
    model_answer_text text
);


ALTER TABLE public.submissions OWNER TO russpeak;

--
-- Name: topic_images; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.topic_images (
    id uuid NOT NULL,
    topic_id uuid NOT NULL,
    image_key character varying(512) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.topic_images OWNER TO russpeak;

--
-- Name: topics; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.topics (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    name character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.topics OWNER TO russpeak;

--
-- Name: transcripts; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.transcripts (
    id uuid NOT NULL,
    submission_id uuid NOT NULL,
    text text NOT NULL,
    language character varying(16),
    word_timestamps jsonb,
    stt_model character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    pronunciation jsonb
);


ALTER TABLE public.transcripts OWNER TO russpeak;

--
-- Name: users; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    full_name character varying(255) NOT NULL,
    role public.user_role NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    preferred_language character varying(8) DEFAULT 'uz'::character varying NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    google_sub character varying(255),
    xp integer DEFAULT 0 NOT NULL,
    daily_goal integer DEFAULT 1 NOT NULL,
    streak_freezes integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_practice_date date,
    phone character varying(20),
    age integer,
    region character varying(64),
    district character varying(64),
    telegram character varying(64),
    avatar_key character varying(512)
);


ALTER TABLE public.users OWNER TO russpeak;

--
-- Name: xp_events; Type: TABLE; Schema: public; Owner: russpeak
--

CREATE TABLE public.xp_events (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    submission_id uuid,
    amount integer NOT NULL,
    reason character varying(32) DEFAULT 'submission'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.xp_events OWNER TO russpeak;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.alembic_version (version_num) FROM stdin;
c1d2e3f4a5b6
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.app_settings (key, value, is_secret, created_at, updated_at) FROM stdin;
stt_provider	auto	f	2026-07-04 15:01:18.096331+00	2026-07-04 15:01:18.096331+00
\.


--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.assignments (id, teacher_id, student_id, question_id, due_at, created_at, updated_at, group_id) FROM stdin;
76efcbe2-3fd5-4f11-a825-aa9515d84251	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	607e5ea6-022e-4fee-b012-78a186ca42c0	6e680d59-567f-4acd-8c7c-94ec549ac5d4	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
4b4b46f1-6a26-4e68-beca-92b3fb06ce20	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	6e680d59-567f-4acd-8c7c-94ec549ac5d4	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
0ac1cb82-091b-4eca-a417-24bec95fadd5	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	9000ce1c-4db1-499a-a465-34edcabe7f1b	6e680d59-567f-4acd-8c7c-94ec549ac5d4	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
3cba0995-4e10-464a-99b6-0f0d302983e0	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	6e680d59-567f-4acd-8c7c-94ec549ac5d4	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
a3aaca3c-e79f-4a23-a6f6-b6f1c1aa4647	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	6e680d59-567f-4acd-8c7c-94ec549ac5d4	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
bbac2400-f3ea-440f-8a29-ef9f7d38d1d5	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	607e5ea6-022e-4fee-b012-78a186ca42c0	d8be5bd1-5e73-43e0-98dd-a1c61c101082	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
714ec589-a0f6-497f-948d-a6487b401b62	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	d8be5bd1-5e73-43e0-98dd-a1c61c101082	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
c9dde59a-5b72-4079-bf71-4d7826cf02bc	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	9000ce1c-4db1-499a-a465-34edcabe7f1b	d8be5bd1-5e73-43e0-98dd-a1c61c101082	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
cdd1439a-4dc1-4404-bfd9-05770c8d14b7	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	d8be5bd1-5e73-43e0-98dd-a1c61c101082	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
2bb50e33-7b57-4784-af4e-52e885642adf	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	d8be5bd1-5e73-43e0-98dd-a1c61c101082	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.899767+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
017b42d0-8dd9-4e67-866b-c0763205e4dc	395a1ec7-2554-4a7c-b93f-e98c51428b82	6832d92c-b0ef-490d-805c-98cbd726f198	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
00e983de-0dea-47c7-b47d-e8d223210017	395a1ec7-2554-4a7c-b93f-e98c51428b82	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
947648ef-2e95-4b22-8192-33087cf72d9f	395a1ec7-2554-4a7c-b93f-e98c51428b82	662b71e8-b41e-4198-a07c-9fdb8288e651	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
33b3e063-5843-4450-8130-c6cc9e33670c	395a1ec7-2554-4a7c-b93f-e98c51428b82	99bff3a0-8237-4afd-bd58-937faf6cbaae	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
545248e3-456b-431c-b72b-8ea42fefe1de	395a1ec7-2554-4a7c-b93f-e98c51428b82	b584e81c-08dd-4f1f-b181-6e02de1214b0	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
dfb6bff9-1f37-449d-8b04-b218c115b598	395a1ec7-2554-4a7c-b93f-e98c51428b82	6832d92c-b0ef-490d-805c-98cbd726f198	4710821b-14cd-43c0-848a-68798c90df4f	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
56786b4e-aecc-4946-b1c8-6a2e7c68bc3d	395a1ec7-2554-4a7c-b93f-e98c51428b82	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	4710821b-14cd-43c0-848a-68798c90df4f	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
124cd276-12a8-41b6-8fb3-b344190c6528	395a1ec7-2554-4a7c-b93f-e98c51428b82	662b71e8-b41e-4198-a07c-9fdb8288e651	4710821b-14cd-43c0-848a-68798c90df4f	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
806c488d-2fb9-49b7-82f7-5f107e943f75	395a1ec7-2554-4a7c-b93f-e98c51428b82	99bff3a0-8237-4afd-bd58-937faf6cbaae	4710821b-14cd-43c0-848a-68798c90df4f	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
dfd26193-dab7-4265-b480-be3c59b567b2	395a1ec7-2554-4a7c-b93f-e98c51428b82	b584e81c-08dd-4f1f-b181-6e02de1214b0	4710821b-14cd-43c0-848a-68798c90df4f	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.941306+00	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642
cc7e4a4e-134a-471c-a597-5280a0f0c522	656f43bd-8532-481b-bc31-aed8cb9abaad	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
b1000bed-2924-47ae-8bcc-3c7f1a1dd7cd	656f43bd-8532-481b-bc31-aed8cb9abaad	6f394335-b63b-4c72-b929-78733facb505	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
de1bdb3b-cbff-4768-b44c-3e7102c27410	656f43bd-8532-481b-bc31-aed8cb9abaad	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
ac645564-9630-436f-b2ce-eff0ea663544	656f43bd-8532-481b-bc31-aed8cb9abaad	1f8f0810-c92e-48f5-9bc7-eda00173e390	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
a6dd7d6d-4b52-4e53-8c27-20f1f1bc711b	656f43bd-8532-481b-bc31-aed8cb9abaad	51cfb12f-6865-4891-8342-aec015a5f60c	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
2d58c2cc-d226-4922-9598-347fc03372db	656f43bd-8532-481b-bc31-aed8cb9abaad	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	cc92ed85-1500-4364-a12e-00e891ff6916	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
c63db93d-21b9-405a-a9e3-e50d5b92df4e	656f43bd-8532-481b-bc31-aed8cb9abaad	6f394335-b63b-4c72-b929-78733facb505	cc92ed85-1500-4364-a12e-00e891ff6916	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
315b10fc-af73-4911-a942-5349d8bb8263	656f43bd-8532-481b-bc31-aed8cb9abaad	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	cc92ed85-1500-4364-a12e-00e891ff6916	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
df92d570-79eb-446f-87cd-f4452c820900	656f43bd-8532-481b-bc31-aed8cb9abaad	1f8f0810-c92e-48f5-9bc7-eda00173e390	cc92ed85-1500-4364-a12e-00e891ff6916	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
7b4f79a1-b187-462b-b1bb-a97153bc0384	656f43bd-8532-481b-bc31-aed8cb9abaad	51cfb12f-6865-4891-8342-aec015a5f60c	cc92ed85-1500-4364-a12e-00e891ff6916	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.97152+00	d3d373d3-1947-495d-bc2a-520eac62b7a2
536a9085-5dd9-49e8-925e-6a8e64c5c1ea	f604d00d-599b-434e-8535-d069cccac127	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
a290c405-8cf3-48ab-b35c-9686693d4ac3	f604d00d-599b-434e-8535-d069cccac127	13b13315-eb4e-4da6-b645-e558bf78f6db	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
dbeb482c-0060-4e2f-b7b7-44516ce527a3	f604d00d-599b-434e-8535-d069cccac127	182470a9-678c-4231-bbbf-41d427773497	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
db18d9f0-9b6f-4fa9-b9f0-7e70cfa0c98f	f604d00d-599b-434e-8535-d069cccac127	8f73affc-cb6c-4b19-92fc-2337385eb851	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
2f57228a-bbef-42f1-bb11-b0cda6a8fd6d	f604d00d-599b-434e-8535-d069cccac127	12b3b088-bdf0-4379-b2a7-aeae73280ea6	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
5d7231a6-e594-462f-b3d2-09af1dedb229	f604d00d-599b-434e-8535-d069cccac127	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	9b0540c0-82dd-473c-b648-5f3abf3af39c	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
38aa0c45-3fbc-4738-878a-7e462c3e736d	f604d00d-599b-434e-8535-d069cccac127	13b13315-eb4e-4da6-b645-e558bf78f6db	9b0540c0-82dd-473c-b648-5f3abf3af39c	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
1671621b-3741-4400-a508-987ab9b5de37	f604d00d-599b-434e-8535-d069cccac127	182470a9-678c-4231-bbbf-41d427773497	9b0540c0-82dd-473c-b648-5f3abf3af39c	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
da75b3fd-d451-4c41-8763-73cf4753f98f	f604d00d-599b-434e-8535-d069cccac127	8f73affc-cb6c-4b19-92fc-2337385eb851	9b0540c0-82dd-473c-b648-5f3abf3af39c	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
90d6edda-ebe0-40ce-a4e6-298855949fd6	f604d00d-599b-434e-8535-d069cccac127	12b3b088-bdf0-4379-b2a7-aeae73280ea6	9b0540c0-82dd-473c-b648-5f3abf3af39c	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.000305+00	32cb96df-6211-4892-99fb-70ab15648936
9ce79ce3-d9d4-4c1a-9bf2-6659ae918a16	57917a22-78cf-497e-94bb-a4813c056f6f	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	4b516865-9bc6-45f7-b38f-5798c7f538b1	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
380b3e62-20fa-40ea-a5f5-9c3dfca51402	57917a22-78cf-497e-94bb-a4813c056f6f	86df832e-096f-4174-b022-a932fedefca0	4b516865-9bc6-45f7-b38f-5798c7f538b1	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
be4715f5-03c6-4d51-abe1-eb260900eb05	57917a22-78cf-497e-94bb-a4813c056f6f	2715a5ba-2133-4fe9-af71-83c274e65cbc	4b516865-9bc6-45f7-b38f-5798c7f538b1	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
b59e946e-5966-4a64-b9f2-205a6cae6328	57917a22-78cf-497e-94bb-a4813c056f6f	8149a2f8-99af-4e89-a11e-89fb61297ef1	4b516865-9bc6-45f7-b38f-5798c7f538b1	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
9263326c-a0d2-4228-8efd-38c140c01234	57917a22-78cf-497e-94bb-a4813c056f6f	85a2e644-0cee-439c-88fb-590ea4128006	4b516865-9bc6-45f7-b38f-5798c7f538b1	2026-07-07 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
b7859ef4-9acd-42a8-8993-b0589db96055	57917a22-78cf-497e-94bb-a4813c056f6f	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	802b412a-e6cd-4256-ab70-9adf3bb83a9e	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
04a91731-52df-4a3f-aad6-3eeaf2bdc18d	57917a22-78cf-497e-94bb-a4813c056f6f	86df832e-096f-4174-b022-a932fedefca0	802b412a-e6cd-4256-ab70-9adf3bb83a9e	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
68a9b282-27f2-4c04-84cf-0e18e1b350d8	57917a22-78cf-497e-94bb-a4813c056f6f	2715a5ba-2133-4fe9-af71-83c274e65cbc	802b412a-e6cd-4256-ab70-9adf3bb83a9e	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
5392df78-31d4-4af7-af32-ec74553eb299	57917a22-78cf-497e-94bb-a4813c056f6f	8149a2f8-99af-4e89-a11e-89fb61297ef1	802b412a-e6cd-4256-ab70-9adf3bb83a9e	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
195ae539-5dfc-45bc-b0b2-0a519ccbfcf7	57917a22-78cf-497e-94bb-a4813c056f6f	85a2e644-0cee-439c-88fb-590ea4128006	802b412a-e6cd-4256-ab70-9adf3bb83a9e	2026-07-08 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:14.031101+00	4310c64c-e399-4b56-ab88-91a44e38ff0d
789673bf-dcc5-44bf-a811-020ceb028ccc	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	85e60dda-c33d-4964-a0b2-cd70471283a2	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
681cbb58-5db3-4e72-a789-8294abf44192	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	10dda6f5-02d9-4759-9a89-056a9492075c	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
2ef569e7-3980-4916-ae97-cfb687b492cd	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	436b1878-65ab-4711-81fa-64d9dfbae545	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
37ee0020-adba-46e1-973b-0539b48b009d	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	85e60dda-c33d-4964-a0b2-cd70471283a2	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
523bc452-79ee-446c-b025-a838edb1c7c3	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	10dda6f5-02d9-4759-9a89-056a9492075c	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
70818038-6334-4600-a113-78f2776de5e7	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	436b1878-65ab-4711-81fa-64d9dfbae545	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
8c30c31a-6c48-4d54-9866-f659a71ef180	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	607e5ea6-022e-4fee-b012-78a186ca42c0	85e60dda-c33d-4964-a0b2-cd70471283a2	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
004a4b07-6a5b-458e-b57c-35213266f68d	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	607e5ea6-022e-4fee-b012-78a186ca42c0	10dda6f5-02d9-4759-9a89-056a9492075c	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
a71fdbab-199e-40dc-b3d5-039146455fdb	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	607e5ea6-022e-4fee-b012-78a186ca42c0	436b1878-65ab-4711-81fa-64d9dfbae545	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
f309962c-fc64-4388-bb01-e6d1328e142d	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	9000ce1c-4db1-499a-a465-34edcabe7f1b	85e60dda-c33d-4964-a0b2-cd70471283a2	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
24bf8eca-5e21-4d8c-ad95-ce76c5170376	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	9000ce1c-4db1-499a-a465-34edcabe7f1b	10dda6f5-02d9-4759-9a89-056a9492075c	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
dbb887c5-61c5-403e-bad9-db46cf98dde6	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	9000ce1c-4db1-499a-a465-34edcabe7f1b	436b1878-65ab-4711-81fa-64d9dfbae545	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
11c06ec7-f7c5-4c53-b608-162a6b274342	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	85e60dda-c33d-4964-a0b2-cd70471283a2	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
ae5ceaea-de38-46a1-8a96-bd989161f2f2	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	10dda6f5-02d9-4759-9a89-056a9492075c	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
6683509c-75c6-4281-80f6-25621c013ebc	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	436b1878-65ab-4711-81fa-64d9dfbae545	2026-07-01 00:00:00+00	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00	59d461db-1b77-4ef7-97d8-5a90c01c64cd
\.


--
-- Data for Name: evaluations; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.evaluations (id, submission_id, fluency_score, lexical_score, grammar_score, pronunciation_score, overall_band, feedback, corrections, llm_model, created_at, updated_at, relevance_score, explanation, level_score, naturalness_score, speech_rate_score, intonation_score, native_likeness) FROM stdin;
db8138e0-9349-4ca6-9f24-0b6f250e0241	0edd8fb7-d6fd-4f96-9d3a-cae4cfe1d7da	75.7	83.4	48.4	\N	68.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	67.7	\N	77.2	\N	\N	\N	\N
42e9fe64-4776-4a89-b600-f0041b51b48b	54d45ccc-ad23-41c1-9171-22fb4b9e785e	51	53.6	70.3	\N	61.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	72.9	\N	72.5	\N	\N	\N	\N
bfe91eec-7d74-48bf-9a39-f0871ad13a78	3f43c22e-cbdb-44bb-a828-5f553b3eedb2	50.2	79.7	72.2	\N	66.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	64.3	\N	76.5	\N	\N	\N	\N
2994e10c-931d-4b49-9f5a-11792623bef2	4d836253-0a6a-40df-b086-3e6318281c44	53.7	81.4	68.5	\N	71.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	83.9	\N	88.7	\N	\N	\N	\N
0f84914a-32b6-47d5-bc43-698917dc1a00	e42cb28b-7ffc-4a3f-9610-2e3e73f428e4	64.4	68.7	77.3	\N	71.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	76	\N	89.9	\N	\N	\N	\N
1ea60155-abf8-4652-a718-6eb20f112a2b	71a0dd5e-fca5-4458-a856-4e68777b43de	64.4	64.5	77.5	\N	65.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	56.8	\N	78.1	\N	\N	\N	\N
cb6f4057-fc16-4a1a-8406-d24b65480e32	f756aacb-5f37-473e-a451-d374bc40ab16	76	48.1	69.8	\N	66.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	72.4	\N	77.5	\N	\N	\N	\N
1cf82e23-7dc6-4655-a910-fcf6ffeaea5a	7ffc76f7-0ac4-43e7-9fea-de41ff0f5bd2	85.2	74.6	53.6	\N	69.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	63.6	\N	86.4	\N	\N	\N	\N
97983cd6-7b5e-415f-b8fb-b2cff5c67540	495f9102-c7d9-42b9-b358-aa3884aa4b25	80.6	62.3	47.6	\N	69.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	88.4	\N	84.5	\N	\N	\N	\N
ba40125c-60db-4f2d-8019-6a762eec1783	98bd9179-d490-416a-97bc-1a7390026fde	65	84.3	62.9	\N	68.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	61.1	\N	79.3	\N	\N	\N	\N
33e35f79-909e-4323-8e68-d27fd084d64e	f90a1068-a5e3-49fb-ad2f-0df9e0b11940	53.5	47	49.3	\N	56.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	76.4	\N	74.1	\N	\N	\N	\N
0bca8780-df41-4a40-8423-7b0a41064a20	d5bcba45-e4cf-4c88-b53f-87e80a3ccebd	64.5	87.8	65.6	\N	77.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	90.8	\N	95.5	\N	\N	\N	\N
a6bcdf36-657b-48ea-9bf3-17a2f41ea6c2	9263acef-c8cd-4602-a47d-58f87d55cce5	70.4	56.5	70	\N	62.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	54.7	\N	76.1	\N	\N	\N	\N
655e4b25-405b-404b-9abc-24d75b6da0f0	6cfca392-aba9-410b-9a34-a3d45ea95b51	83.3	56.3	64.5	\N	65.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	57.5	\N	84.4	\N	\N	\N	\N
9bd2cb33-b182-4134-b8ba-3951766316c6	5225ae61-40e1-4a32-815f-4d2641f7d065	69.3	53.6	59.6	\N	59.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	56.8	\N	79.2	\N	\N	\N	\N
47b2b765-c062-413b-bbde-a3bc0d1b96c1	9ca9d239-bd66-40de-8ee0-5ef980545bfe	83.4	80.8	57	\N	68.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	52.4	\N	86.9	\N	\N	\N	\N
6fd2066e-a437-4cd4-8ba6-6447fe163b9a	83d77585-5719-44b0-ac59-f6977e014e6c	81	87.1	65.8	\N	72.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	55.3	\N	88.2	\N	\N	\N	\N
798e01fb-f1d7-4b4e-be17-acb373edce57	ce21e2a4-781d-40b6-af08-293ec290d2ef	83.2	63.2	53.3	\N	68.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	72.7	\N	84.9	\N	\N	\N	\N
f284475a-719d-4bb9-abf9-1774e318e3dd	2b9a4f94-cdb6-432e-bc8b-24e1994aea14	58.5	59.5	67.9	\N	61.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	59.7	\N	72	\N	\N	\N	\N
3ec6e2e9-87af-40d7-bc61-5934db8bcf39	0bb4e935-9c4b-4b45-af31-58f4a31641b2	52.6	46.4	57.9	\N	57.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	71.6	\N	68.4	\N	\N	\N	\N
1ecd0f9d-7519-4d37-8ac0-3e093497115a	d8612cb3-1555-4dbc-841b-105785ec214d	77.5	82.9	67.5	\N	72	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	60.2	\N	85.7	\N	\N	\N	\N
d19833a4-738e-4a2f-a8cd-5c1eec5107f7	94dca90e-6adc-4e44-ab6d-7266c1b4129d	75	60.2	61	\N	70.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	86.3	\N	79.3	\N	\N	\N	\N
c4fa1e35-b9ae-4578-a08e-d9e7621aa8d0	cea5aa89-43dd-4fbf-bdf6-668d3d3fbcdb	65.3	59.6	78.6	\N	66	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	60.4	\N	76.3	\N	\N	\N	\N
ff9d1313-6eb8-41e1-8c39-3f3678a46f8e	e83bfa36-844d-4100-a358-0794d8e1b38f	52.9	79.7	78.4	\N	66.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	54.1	\N	82.1	\N	\N	\N	\N
25411e53-5dff-4d20-8b46-b96e095bf1dd	5e3289f7-48bf-47d8-b6a1-73cf4a201935	85.2	81.5	51.5	\N	72.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	70.4	\N	82.8	\N	\N	\N	\N
5c2bd3ce-51d3-4c98-8789-6860415e7000	7e1721fd-8c95-44ff-b0c5-3b2d9b8877ab	50.1	61.8	81.1	\N	69	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	83	\N	80.4	\N	\N	\N	\N
ef240d82-38b8-4f9e-bf23-51f1ab727e3f	16c1a37b-293b-4906-a5f6-98a76614d0b4	52.3	58.5	47	\N	57	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	70	\N	76	\N	\N	\N	\N
5898beb6-07eb-4131-ba39-efec1dcdabff	9ffd376c-ae9f-4d8f-85c8-dc4a9bd4d2c9	69.3	81.6	47.7	\N	62.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	52.9	\N	81.2	\N	\N	\N	\N
21f28151-78ad-47c1-86a4-9595d9960e6a	8f40f70d-462d-4721-9ac9-a48651706869	71.6	69.9	46.5	\N	60.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	53.4	\N	76.3	\N	\N	\N	\N
b24e36bd-3c76-49ea-988c-79322ff4b927	a0c23ea8-77bc-4eff-902c-158bf503b9ff	59.9	73.8	57.3	\N	63	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	61.2	\N	72.6	\N	\N	\N	\N
2d696d73-fd43-4f61-9f3b-a20733e4a556	91f2163f-8848-4700-bb02-cda2410227ec	85.3	85.2	45.4	\N	73	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	76.1	\N	87.8	\N	\N	\N	\N
97d57d1a-abf5-41f3-bd9a-a4823559f90f	9884e60a-3824-4c5b-87ff-21e3392bd679	83.5	82.8	59.4	\N	70.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	56.6	\N	88.6	\N	\N	\N	\N
312ef87f-fe42-456c-b8c0-b5c9fa31b5e5	216f4459-017f-44f8-a396-c347c10aeb7e	80.7	67.7	71	\N	73.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	73.3	\N	92.4	\N	\N	\N	\N
b47ba7dc-e2ba-46e5-bae0-3015ad70e391	1764a08c-5437-4934-8c36-4a52fe8be50f	83.8	76.9	51.1	\N	68.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	61.8	\N	78.9	\N	\N	\N	\N
8f00f1a3-7271-421a-b0fb-b0d4971a153a	f69940b2-96fa-4e98-bfbb-014af377cf43	81.5	46.9	58	\N	60.5	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	55.5	\N	80.3	\N	\N	\N	\N
abb40efa-c4df-4bad-a60e-b48b31056be9	4f1a70dd-699f-47f9-9249-4d9159ff1779	66.3	45.4	47.9	\N	61.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	87.1	\N	80.5	\N	\N	\N	\N
82c46617-198f-4ab5-9edc-dd3c8c8a6080	6ced6c01-eed9-427f-a03f-15aa27cb6b28	72.1	51.4	50	\N	59.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	62.9	\N	77.9	\N	\N	\N	\N
f04319a2-2d07-4b92-b773-60c43374921d	66a1d5b4-7907-4b3a-88ad-fb78cea62395	65.4	71.7	51	\N	69.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	89.1	\N	87.7	\N	\N	\N	\N
f1d5e133-08e8-4d6b-96f0-6bd70e63e4b8	95b44407-9a6e-4115-b18e-3dcaf8fd54c3	78	59.3	81.3	\N	75.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	83.7	\N	94	\N	\N	\N	\N
1bb83c39-b903-4054-b629-1edcdc73fbcd	5f4ebf45-1bfe-475c-a858-6ac668d5171f	76.6	61.4	46.5	\N	63.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	69.8	\N	74	\N	\N	\N	\N
b5229d91-7f4b-419e-8f46-89c9e191811c	d73fb91d-6a83-4158-9356-9a49ef6447d2	80.2	54.8	45.9	\N	59.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	58.1	\N	71.7	\N	\N	\N	\N
c9946cd2-69c3-4580-8c37-70f86640965b	45673d97-c4d0-4680-9bc5-665e72a7995e	59.9	70	83.4	\N	66.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	51.6	\N	81.4	\N	\N	\N	\N
a12de201-74ea-4e8f-a02d-d0ffcb7791ff	f61fde7d-326d-4462-a5ff-ef66df54d9e7	87.4	50	80.1	\N	68.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	58	\N	77.4	\N	\N	\N	\N
9bd80aae-54fa-46cc-b6fb-57e7af7ac4b6	09a5bf13-99a0-42e5-97dd-1012a92b88f6	80.6	74.5	81.7	\N	79.5	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	81	\N	89.9	\N	\N	\N	\N
1e757559-1cbc-418f-92d5-110583ed2af5	6e76bbb7-54ee-4662-97c6-aaabec0462b5	85	71.8	70.9	\N	70.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	55.2	\N	89.5	\N	\N	\N	\N
6dbada92-ab81-4a52-8be5-e248db3dded5	fede438b-b7c4-4ae1-a583-e09bf7214c41	75.3	61.3	74.2	\N	67	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	57.3	\N	81.8	\N	\N	\N	\N
dde62143-af23-47ff-a571-71a439595ccd	6cea0ca9-3583-429e-8102-a5a4fd364193	61.5	54	75.6	\N	66.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	75.5	\N	78.6	\N	\N	\N	\N
8bbeb894-e4da-4e32-add3-2fcd9140a008	768cfd45-f415-46cb-86f0-c1e3f4d96671	69.4	79.1	82.4	\N	78	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	80.9	\N	93.9	\N	\N	\N	\N
43909d4d-1eb4-445d-a6db-f9142cf0ae40	f94ebff4-9fb7-4883-b15a-fb25e3248cb9	73.5	49	82.1	\N	66.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	59.9	\N	77.8	\N	\N	\N	\N
7028ec7d-a440-49f5-a939-1fdd28a8bcb0	3f0f9ced-e914-42c7-af90-cbab87e325de	52.8	62.8	69.6	\N	60.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	58.2	\N	77.2	\N	\N	\N	\N
5552b30e-fa59-4e00-8c17-f4bab0d8caf7	8c667cad-e6d6-4470-8af7-04e82391ae6e	74.9	45.2	74.3	\N	69.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	82.3	\N	78.5	\N	\N	\N	\N
6d371369-295b-48c4-acbd-fa3a3849cca4	b9238b70-4c37-438d-a88a-aa3ec56c9b71	86.4	67.3	47	\N	65.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	60.5	\N	83.5	\N	\N	\N	\N
87039e68-72f8-41a7-886e-81823ab5d874	31a5ec23-c1e5-4c8c-a4cc-39d17b9d98ab	84.5	64.2	51.2	\N	71.5	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	86.2	\N	84.9	\N	\N	\N	\N
c5f81a93-3159-44c5-9642-90bafa10b088	4e5e81be-363f-481d-80b5-2430fff7a5ca	79.6	65.8	54.3	\N	67	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	68.5	\N	83.6	\N	\N	\N	\N
2a4fbd6f-c06f-46fc-bca3-b1610adb1fd1	8e4bb48a-9e44-4c18-ab58-7fe2359df794	83.9	48.5	50.9	\N	62.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	66.1	\N	72.2	\N	\N	\N	\N
a83cb591-36ee-4464-864a-cf5584fb4793	aa72dd02-86f7-4c19-85cb-7b5cae529831	57.9	63.1	80.3	\N	69	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	74.5	\N	85.3	\N	\N	\N	\N
a9c55ed3-1884-462d-8d43-fe9b2cef89ed	2f47ca19-057d-4980-b3df-1c319a8a2dab	85.8	57.8	60.2	\N	72.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	87.4	\N	90.8	\N	\N	\N	\N
7f351b09-aa98-408e-b313-2fcf03fa2708	40eb9350-7635-431e-ae7c-aa753f1e0e9a	84.1	66	55.6	\N	69	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	70.4	\N	81.7	\N	\N	\N	\N
6f03c726-3898-48cc-9f0b-2e5ab23c8fd1	b23fc5ca-10ac-471e-a2cd-c51adabc7658	53.2	63.4	78.8	\N	63.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	57.6	\N	74.3	\N	\N	\N	\N
7f687cb9-a0f6-4758-be9d-2a8588d28bf1	66d09a8f-023b-40c5-9221-59d12805cc2c	62.8	82.8	55.9	\N	72.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	90	\N	86	\N	\N	\N	\N
8d2a0488-d818-4432-bcd2-0751e9af7048	4bbe2fbb-ce58-4e74-8e36-ffde513b5ad9	70.5	88	58.6	\N	73.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	77.3	\N	91	\N	\N	\N	\N
1664421b-06e7-4d6a-8917-f9b26a5599d3	fb4a92cb-afa8-4657-be68-08d63ac9dd2e	86.1	53.6	45.8	\N	60.5	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	56.4	\N	70	\N	\N	\N	\N
59d7c30c-1492-40f3-8d63-8d09ef18b60d	0b5d5bcf-d14f-4edf-9c29-8b00533bb9de	58.3	75.1	74.9	\N	66.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	57	\N	81.6	\N	\N	\N	\N
115bd0d9-f353-45fb-bc9f-328d2e5c65a7	09952ee0-3b05-49ef-8db4-519bd3a4b743	84.5	61.1	81.7	\N	71.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	58.3	\N	86.5	\N	\N	\N	\N
e771eff6-2d67-47c4-9585-15395ea45ce2	9018bd1e-547c-4a3f-8199-b78b8f4404e1	79.4	81.6	68.4	\N	71.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	55.1	\N	90.9	\N	\N	\N	\N
98c84c07-93b8-46f4-b0b4-b65f9fadc90d	48247057-f810-48f7-8cc4-0ac3cff4b84a	75.1	48	70.3	\N	61	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	50.5	\N	74	\N	\N	\N	\N
ad075352-c827-4890-8b67-bce4a3719208	f36ea940-be4f-42e5-846e-419f87f21c02	77.9	86.5	55.5	\N	76	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	83.9	\N	90.5	\N	\N	\N	\N
3e884e3f-5e97-41cd-8fc1-03566a455c22	e10f3719-3b8f-495c-b438-b3c8859e890b	77.8	56.5	78.2	\N	74.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	84.9	\N	83.3	\N	\N	\N	\N
5057d29c-31b8-4962-a211-52298ade474e	419ec27e-11e0-478f-b62d-791043fd431e	71.7	73.7	58.1	\N	68.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	70.8	\N	80.5	\N	\N	\N	\N
08a5a2c4-2ab8-4ab8-938f-828c42e1e4e8	7b39b83e-43cb-440f-88df-b77b00d99a6f	60.5	45.4	82	\N	60.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	53.6	\N	77	\N	\N	\N	\N
1676e664-eed1-482f-8a9a-e40b1a60aa60	755eb452-2de0-4151-bff3-f279c077aea0	76.2	72.8	64.1	\N	74.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	83.3	\N	83.2	\N	\N	\N	\N
018f7364-bb1d-42c6-9414-80ee5b59ad11	ed953bc7-0e32-4f29-951a-790dcae2b4a1	61.6	70	63.5	\N	66.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	72.3	\N	79.9	\N	\N	\N	\N
10ff2db2-2520-4d2a-bca5-4042da9c8aef	8b6c5e05-3c6e-40fb-a086-4401c4390637	57.3	50.1	65.9	\N	63.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	82	\N	74	\N	\N	\N	\N
9233b9db-5e58-49c5-8f74-c687d05aaa16	3083ed90-1c08-43bb-8676-ba214c62916e	72.4	77.7	68.3	\N	77.4	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	91.2	\N	95.4	\N	\N	\N	\N
c004cd23-f517-4982-8da3-62dc6382e9fc	a690611f-b1e0-476c-95dd-914648dd1d12	61.5	75.4	49.9	\N	59.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	51.9	\N	68.4	\N	\N	\N	\N
600fe7c7-22a4-468d-a6a5-e8e50ac14074	e031cbea-392d-4bb6-8053-7f178866c88c	78.6	49.4	45.5	\N	58.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	61.9	\N	72.6	\N	\N	\N	\N
10a5ee84-f63d-4483-a1aa-6a90b0d4ab3f	d62885ce-cc8e-4f98-9606-438cd9443325	52.8	72.1	47.1	\N	57.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	56.3	\N	71.9	\N	\N	\N	\N
613b23f5-90b4-4d43-bd36-644e2df5fb6c	8dd27d45-c888-436a-b978-4695143b170c	54.5	77.9	68.6	\N	71	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	83.2	\N	81.7	\N	\N	\N	\N
167ae089-99df-4c22-85da-3f928246809d	2b4efca5-c485-42d5-9702-46c4bec8c069	66.8	82	83.6	\N	73.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	62.8	\N	89.3	\N	\N	\N	\N
02b49b8e-1384-4f2a-8718-8ee3b8586f92	c16922f7-8eae-4794-8003-01b25d98ce4f	71	51.7	60.9	\N	65.7	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	79	\N	79.3	\N	\N	\N	\N
68e3b3fd-8412-4038-b893-806929a639cd	cf1d1cef-9c87-4628-8948-2d61eceeea95	60.7	82	47.8	\N	62.6	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	59.8	\N	73.8	\N	\N	\N	\N
7230a3e5-ce8d-41e8-9e6e-d23f00b8271b	c72a58aa-bd06-474c-827c-d79c305d72f5	85.5	63.3	66.2	\N	73	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	77.2	\N	91.9	\N	\N	\N	\N
7971586e-a597-402f-9bb5-e374bf686bb8	fef4d6f8-f062-4f15-8c37-9f34897d1255	66.7	65.2	56.9	\N	63.9	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	66.9	\N	75.2	\N	\N	\N	\N
f0a69dd5-baf1-4f7e-9dbe-6b0b95464fad	a4541fb8-3afe-4450-a8db-0f3ceac92429	72.7	83.2	73.6	\N	76.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	75.4	\N	84.5	\N	\N	\N	\N
67842845-e316-4a31-a2cd-cda11f8263d0	5d986e15-5051-4878-a4a4-3cddbda19f39	50.8	77.9	77	\N	70	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	74.2	\N	87.2	\N	\N	\N	\N
4d98ed1c-4c05-4227-9728-65f4a1066ee7	663ebcec-4836-4b45-98af-f9fff4b7feef	68.7	48.9	58.6	\N	60	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	64	\N	76	\N	\N	\N	\N
d89d4882-db68-401b-aa54-ab117e367877	0562f646-5808-4135-a753-4b75cee4c572	68.8	73.5	60.6	\N	71.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	81.9	\N	79.6	\N	\N	\N	\N
d5a9fb29-f9ce-4835-ab13-f129404aef6f	d1a855a9-40e8-41b7-82ee-54d09533864c	54.4	78.2	78.7	\N	74	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	84.6	\N	82	\N	\N	\N	\N
cd484067-b950-46e7-9204-f41230a125a8	e5994e27-be8a-4845-ab4f-2b5a572eb3af	57.1	60.6	74.5	\N	67.1	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	76.3	\N	84.2	\N	\N	\N	\N
36b631f2-62c6-4108-93c6-21bf4cd96867	93304d73-fbcc-42bc-8307-e5503b13b3f7	73.9	79.4	72.7	\N	72.3	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	63.1	\N	80.5	\N	\N	\N	\N
35a36883-f13a-4676-81da-2f379fb67285	bf818566-9785-4f3f-a8d9-07d8e36f5ce5	82	49.9	81.9	\N	72.8	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	77.2	\N	82.6	\N	\N	\N	\N
e37f8f2d-eaae-4225-bd85-4cd3655665e9	42920bf0-86de-4946-955d-4ebf2c021e6d	65.8	65.7	63.4	\N	66	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	69.2	\N	75.7	\N	\N	\N	\N
75c9c5da-e5aa-45fb-b7e0-709be22d3361	6fe0ce58-4e1e-43f7-aa39-7d5620976a3f	83.4	82.2	55.8	\N	76.2	{"summary": "Хороший ответ. Старайтесь использовать больше связок между мыслями и следить за падежами.", "strengths": ["Понятная речь", "Хороший словарный запас"], "improvements": ["Падежи существительных", "Темп речи"], "vocabulary_suggestions": ["впечатление", "путешествие", "достопримечательность"]}	[{"type": "word_order", "original": "я ходил в магазин вчера", "corrected": "вчера я ходил в магазин", "explanation": "Обстоятельство времени лучше поставить в начало."}]	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	83.2	\N	89.2	\N	\N	\N	\N
a1bfa2ab-efd7-4d04-8428-678763e1b0d0	11ff5003-d2b8-4b46-8252-0641f27e061c	20	15	10	70	25.2	{"summary": "Studentning javobi juda qisqa va tushunarsiz. U o'zining sevimli taomlari haqida gapirmadi va savolga to'liq javob bermadi.", "strengths": ["Student savolga javob berishga harakat qildi."], "improvements": ["Javobni kengaytirish va aniqroq qilish kerak.", "Sevimli taomlar va oshxonalar haqida ko'proq ma'lumot berish lozim."], "orthoepy_errors": [], "vocabulary_suggestions": ["пицца", "паста", "салат", "десерт", "вкусный"]}	[{"type": "relevance", "original": "расскажите что вы любите если какой нибудь проект почитайте", "corrected": "я люблю есть пиццу и пасту", "explanation": "Student savolga to'liq javob bermadi."}]	gemini-3.1-flash-lite	2026-07-09 05:38:32.70167+00	2026-07-09 05:38:32.70167+00	10	\N	22	\N	\N	\N	\N
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.group_members (id, group_id, student_id, created_at, updated_at) FROM stdin;
8d4c7083-690d-459a-abd0-7ad1995f4e39	59d461db-1b77-4ef7-97d8-5a90c01c64cd	607e5ea6-022e-4fee-b012-78a186ca42c0	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
f61f0ca0-cae3-4c36-9bf9-a4f58c1fa2ee	59d461db-1b77-4ef7-97d8-5a90c01c64cd	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
332de3d0-d9a9-4630-8c2b-1336f1dfdbfe	59d461db-1b77-4ef7-97d8-5a90c01c64cd	9000ce1c-4db1-499a-a465-34edcabe7f1b	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
35ca0fdd-a8f1-4d80-8cb6-dd53760cd703	59d461db-1b77-4ef7-97d8-5a90c01c64cd	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
07c6aed8-1950-4007-8fa9-91d0b31d1fa9	59d461db-1b77-4ef7-97d8-5a90c01c64cd	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
f8e48b24-ba23-452d-816a-dd9488c19f99	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	6832d92c-b0ef-490d-805c-98cbd726f198	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
a975ee9c-9ecc-41d2-af94-906bafff0d7d	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
089fbe6c-6420-484f-9aa8-f91e2a60aa83	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	662b71e8-b41e-4198-a07c-9fdb8288e651	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
607296cf-b363-4f95-8888-5b8267ec68c3	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	99bff3a0-8237-4afd-bd58-937faf6cbaae	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
b26756ba-d2ec-4242-9ccb-92332025f997	9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	b584e81c-08dd-4f1f-b181-6e02de1214b0	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
98d0b710-c7f8-4588-8f52-77e8c12fe981	d3d373d3-1947-495d-bc2a-520eac62b7a2	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
2b6b8a3b-bf32-4245-b0f4-b3ebb654a6c0	d3d373d3-1947-495d-bc2a-520eac62b7a2	6f394335-b63b-4c72-b929-78733facb505	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
dfb2162e-31af-42ce-9936-ed4dbce80653	d3d373d3-1947-495d-bc2a-520eac62b7a2	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
81ef3546-7e24-49b4-858e-782a80fe530b	d3d373d3-1947-495d-bc2a-520eac62b7a2	1f8f0810-c92e-48f5-9bc7-eda00173e390	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
1e8959ae-c4e0-4b31-8198-c4561e61eaf5	d3d373d3-1947-495d-bc2a-520eac62b7a2	51cfb12f-6865-4891-8342-aec015a5f60c	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
7c8cb13b-5b67-4f9a-a1a8-77f3dc1f3a8e	32cb96df-6211-4892-99fb-70ab15648936	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
77ba1c78-5b07-48f7-9587-e12efb7df61b	32cb96df-6211-4892-99fb-70ab15648936	13b13315-eb4e-4da6-b645-e558bf78f6db	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
61d532b2-8db2-4324-b256-c139335db4a9	32cb96df-6211-4892-99fb-70ab15648936	182470a9-678c-4231-bbbf-41d427773497	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
e5dfd188-3f3b-499c-bc26-7c6b3aaa933b	32cb96df-6211-4892-99fb-70ab15648936	8f73affc-cb6c-4b19-92fc-2337385eb851	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
370db9f7-a251-44e7-aff4-d7159dbf1f08	32cb96df-6211-4892-99fb-70ab15648936	12b3b088-bdf0-4379-b2a7-aeae73280ea6	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
4c22e0c2-1c48-4522-8113-00b7e746b109	4310c64c-e399-4b56-ab88-91a44e38ff0d	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
b0a8a713-93b7-46e6-8f84-29f75474e978	4310c64c-e399-4b56-ab88-91a44e38ff0d	86df832e-096f-4174-b022-a932fedefca0	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
3c8cd622-6b26-4b54-bc2a-05aec3c2cf62	4310c64c-e399-4b56-ab88-91a44e38ff0d	2715a5ba-2133-4fe9-af71-83c274e65cbc	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
72a02a86-6bc7-462b-aa8e-85247548e349	4310c64c-e399-4b56-ab88-91a44e38ff0d	8149a2f8-99af-4e89-a11e-89fb61297ef1	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
4a786e82-12f6-4a1f-a54f-1e5103ad6ec7	4310c64c-e399-4b56-ab88-91a44e38ff0d	85a2e644-0cee-439c-88fb-590ea4128006	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.groups (id, teacher_id, name, join_code, created_at, updated_at) FROM stdin;
59d461db-1b77-4ef7-97d8-5a90c01c64cd	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	Группа Ойбек	NUKFPU	2026-07-04 15:37:13.887468+00	2026-07-04 15:37:13.887468+00
9a3cd1b7-e7b0-49d8-a82b-ff34894b5642	395a1ec7-2554-4a7c-b93f-e98c51428b82	Группа Нигора	4C9ZSN	2026-07-04 15:37:13.935312+00	2026-07-04 15:37:13.935312+00
d3d373d3-1947-495d-bc2a-520eac62b7a2	656f43bd-8532-481b-bc31-aed8cb9abaad	Группа Жасур	UXFRK7	2026-07-04 15:37:13.965654+00	2026-07-04 15:37:13.965654+00
32cb96df-6211-4892-99fb-70ab15648936	f604d00d-599b-434e-8535-d069cccac127	Группа Малика	SCQN4C	2026-07-04 15:37:13.994704+00	2026-07-04 15:37:13.994704+00
4310c64c-e399-4b56-ab88-91a44e38ff0d	57917a22-78cf-497e-94bb-a4813c056f6f	Группа Бекзод	RE4PR3	2026-07-04 15:37:14.024855+00	2026-07-04 15:37:14.024855+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.notifications (id, user_id, type, title, body, link, is_read, created_at, updated_at) FROM stdin;
4fabf2f5-498b-47a9-8550-e22540176739	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00
597f5dee-131a-41da-aa82-37264adcf93d	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00
6ed45b65-971c-4e7d-b7e2-eeef1e3ff0a5	607e5ea6-022e-4fee-b012-78a186ca42c0	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00
2a6a5ea6-2163-489e-a0f4-6938c48c9202	9000ce1c-4db1-499a-a465-34edcabe7f1b	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00
4bb24fd8-2666-40bc-9f49-7421e85da8a8	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:15:40.299697+00	2026-07-06 10:15:40.299697+00
6e39e723-577f-4ec8-8b27-a101361efb17	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:22:00.125181+00	2026-07-06 10:22:00.125181+00
9c975dc6-1e48-4934-a5d9-c794f18a339b	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:22:00.125181+00	2026-07-06 10:22:00.125181+00
56c980df-0328-4cf7-9a93-0a37c0ff39c5	607e5ea6-022e-4fee-b012-78a186ca42c0	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:22:00.125181+00	2026-07-06 10:22:00.125181+00
8346ab50-d105-4814-a45a-6eacb11182c5	9000ce1c-4db1-499a-a465-34edcabe7f1b	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:22:00.125181+00	2026-07-06 10:22:00.125181+00
e45d8859-740e-4769-8815-883be1d5a4f2	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	assignment_new	Yangi modul	Sizga yangi modul biriktirildi: «Обычный русский · Быт»	/assignments	f	2026-07-06 10:22:00.125181+00	2026-07-06 10:22:00.125181+00
71cee80e-7ac9-4d78-9474-aa117aaa0bef	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	result_ready	Natija tayyor	Javobingiz baholandi. Ball: 10/100	/submissions/11ff5003-d2b8-4b46-8252-0641f27e061c	f	2026-07-09 05:25:45.336278+00	2026-07-09 05:25:45.336278+00
f41e2450-6a2a-441a-8922-3f707c905540	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	result_ready	Natija tayyor	Javobingiz baholandi. Ball: 22/100	/submissions/11ff5003-d2b8-4b46-8252-0641f27e061c	f	2026-07-09 05:39:09.444994+00	2026-07-09 05:39:09.444994+00
\.


--
-- Data for Name: question_blocks; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.question_blocks (id, teacher_id, name, topic, level, ru_style, created_at, updated_at, sort_order, visibility, is_published, cover_key) FROM stdin;
3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	Обычный русский · Быт	Знакомство	A1	regular	2026-07-04 15:37:13.893375+00	2026-07-04 15:37:13.893375+00	0	group	t	\N
c5c35de2-7b3f-4b47-98e9-3759e8139598	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	Живой русский · Общение	Разговор	B1	live	2026-07-04 15:37:13.893375+00	2026-07-04 15:37:13.893375+00	1	group	t	\N
6274eee0-3189-4162-ab8a-7027a048f7ce	395a1ec7-2554-4a7c-b93f-e98c51428b82	Обычный русский · Быт	Знакомство	A1	regular	2026-07-04 15:37:13.937707+00	2026-07-04 15:37:13.937707+00	0	group	t	\N
d4723bec-41f6-4973-b443-64d824c76507	395a1ec7-2554-4a7c-b93f-e98c51428b82	Живой русский · Общение	Разговор	B1	live	2026-07-04 15:37:13.937707+00	2026-07-04 15:37:13.937707+00	1	group	t	\N
9e462634-c44d-4bec-89c5-f6ea0db8feb5	656f43bd-8532-481b-bc31-aed8cb9abaad	Обычный русский · Быт	Знакомство	A1	regular	2026-07-04 15:37:13.968142+00	2026-07-04 15:37:13.968142+00	0	group	t	\N
2fd0caa3-5196-4dda-98c8-5afcadcaf550	656f43bd-8532-481b-bc31-aed8cb9abaad	Живой русский · Общение	Разговор	B1	live	2026-07-04 15:37:13.968142+00	2026-07-04 15:37:13.968142+00	1	group	t	\N
8cacb3b1-9440-4891-a007-e2781e878e81	f604d00d-599b-434e-8535-d069cccac127	Обычный русский · Быт	Знакомство	A1	regular	2026-07-04 15:37:13.997069+00	2026-07-04 15:37:13.997069+00	0	group	t	\N
9be2cecd-0812-4d4f-8f54-67e1038b2c7e	f604d00d-599b-434e-8535-d069cccac127	Живой русский · Общение	Разговор	B1	live	2026-07-04 15:37:13.997069+00	2026-07-04 15:37:13.997069+00	1	group	t	\N
9b779ffc-3316-4306-bde0-11e4f0a163b5	57917a22-78cf-497e-94bb-a4813c056f6f	Обычный русский · Быт	Знакомство	A1	regular	2026-07-04 15:37:14.027581+00	2026-07-04 15:37:14.027581+00	0	group	t	\N
6034fda4-ce2c-4b65-9f29-9f35bb9e4242	57917a22-78cf-497e-94bb-a4813c056f6f	Живой русский · Общение	Разговор	B1	live	2026-07-04 15:37:14.027581+00	2026-07-04 15:37:14.027581+00	1	group	t	\N
e931dac3-115d-4083-9029-c40e9ea47109	904bccd8-950a-45ed-afd2-e56a40a99a6b	Ochiq mashqlar	\N	\N	\N	2026-07-05 12:02:43.177305+00	2026-07-05 12:02:43.177305+00	0	public	t	\N
c52e369e-0596-45cc-863e-d5fe7c32980b	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	jjjj	\N	\N	regular	2026-07-05 12:23:43.922065+00	2026-07-05 12:23:43.922065+00	0	group	t	\N
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.questions (id, teacher_id, type, title, prompt_text, media_key, level, prep_time_sec, answer_time_limit_sec, is_published, created_at, updated_at, topic, model_answer_text, is_deleted, is_public, block_id, ru_style, instruction_text, sort_order) FROM stdin;
2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	395a1ec7-2554-4a7c-b93f-e98c51428b82	text	Расскажите о себе	Расскажите немного о себе.	\N	A1	30	120	t	2026-07-04 15:37:13.938662+00	2026-07-04 15:37:13.938662+00	Знакомство	Меня зовут Анвар, мне двадцать лет. Я студент, учусь в университете. В свободное время я люблю читать и гулять.	f	f	6274eee0-3189-4162-ab8a-7027a048f7ce	regular	Представьтесь: имя, возраст, чем занимаетесь. 3–4 предложения.	0
4710821b-14cd-43c0-848a-68798c90df4f	395a1ec7-2554-4a7c-b93f-e98c51428b82	text	Мой обычный день	Расскажите, как проходит ваш обычный день.	\N	A2	30	120	t	2026-07-04 15:37:13.938662+00	2026-07-04 15:37:13.938662+00	Быт	Утром я встаю в семь часов, завтракаю и иду на работу. Днём я работаю и обедаю с коллегами. Вечером я возвращаюсь домой, ужинаю и отдыхаю.	f	f	d4723bec-41f6-4973-b443-64d824c76507	regular	Опишите свой обычный день по порядку: утро, день, вечер.	1
27acb5c7-3e03-4ec1-9650-ba979fbc4066	395a1ec7-2554-4a7c-b93f-e98c51428b82	text	Любимое место в городе	Опишите ваше любимое место в городе.	\N	B1	30	120	t	2026-07-04 15:37:13.938662+00	2026-07-04 15:37:13.938662+00	Город	Больше всего я люблю старый парк в центре. Там тихо, много зелени, и можно спокойно посидеть. Я часто хожу туда с друзьями по выходным.	f	f	6274eee0-3189-4162-ab8a-7027a048f7ce	live	Расскажите о любимом месте в городе и почему оно вам нравится.	2
aaa0a816-6a6f-4a5b-9d63-9d470931775f	395a1ec7-2554-4a7c-b93f-e98c51428b82	text	Планы на выходные	Какие у вас планы на выходные?	\N	B1	30	120	t	2026-07-04 15:37:13.938662+00	2026-07-04 15:37:13.938662+00	Досуг	В эти выходные я хочу отдохнуть. В субботу встречусь с друзьями, а в воскресенье поеду за город. Думаю, будет здорово.	f	t	d4723bec-41f6-4973-b443-64d824c76507	live	Расскажите о планах на выходные: что, где, с кем.	3
abd59234-f9c1-47ca-acaa-24e08f9ecf5c	656f43bd-8532-481b-bc31-aed8cb9abaad	text	Расскажите о себе	Расскажите немного о себе.	\N	A1	30	120	t	2026-07-04 15:37:13.969101+00	2026-07-04 15:37:13.969101+00	Знакомство	Меня зовут Анвар, мне двадцать лет. Я студент, учусь в университете. В свободное время я люблю читать и гулять.	f	f	9e462634-c44d-4bec-89c5-f6ea0db8feb5	regular	Представьтесь: имя, возраст, чем занимаетесь. 3–4 предложения.	0
cc92ed85-1500-4364-a12e-00e891ff6916	656f43bd-8532-481b-bc31-aed8cb9abaad	text	Мой обычный день	Расскажите, как проходит ваш обычный день.	\N	A2	30	120	t	2026-07-04 15:37:13.969101+00	2026-07-04 15:37:13.969101+00	Быт	Утром я встаю в семь часов, завтракаю и иду на работу. Днём я работаю и обедаю с коллегами. Вечером я возвращаюсь домой, ужинаю и отдыхаю.	f	f	2fd0caa3-5196-4dda-98c8-5afcadcaf550	regular	Опишите свой обычный день по порядку: утро, день, вечер.	1
aaebe5d0-90df-47a6-8c73-42deb6f8faef	656f43bd-8532-481b-bc31-aed8cb9abaad	text	Любимое место в городе	Опишите ваше любимое место в городе.	\N	B1	30	120	t	2026-07-04 15:37:13.969101+00	2026-07-04 15:37:13.969101+00	Город	Больше всего я люблю старый парк в центре. Там тихо, много зелени, и можно спокойно посидеть. Я часто хожу туда с друзьями по выходным.	f	f	9e462634-c44d-4bec-89c5-f6ea0db8feb5	live	Расскажите о любимом месте в городе и почему оно вам нравится.	2
4771b3c0-458c-4d18-ba64-eb023c273e88	656f43bd-8532-481b-bc31-aed8cb9abaad	text	Планы на выходные	Какие у вас планы на выходные?	\N	B1	30	120	t	2026-07-04 15:37:13.969101+00	2026-07-04 15:37:13.969101+00	Досуг	В эти выходные я хочу отдохнуть. В субботу встречусь с друзьями, а в воскресенье поеду за город. Думаю, будет здорово.	f	t	2fd0caa3-5196-4dda-98c8-5afcadcaf550	live	Расскажите о планах на выходные: что, где, с кем.	3
0ded0323-938f-4e21-a5a5-15dd71b29e1b	395a1ec7-2554-4a7c-b93f-e98c51428b82	text	Еда и вкусы	Расскажите о вашей любимой еде.	\N	A2	30	120	t	2026-07-04 15:37:13.938662+00	2026-07-04 15:37:13.938662+00	Еда	Я очень люблю плов и домашнюю еду. Ещё мне нравится итальянская кухня, особенно паста. А вот острое я почти не ем.	f	t	e931dac3-115d-4083-9029-c40e9ea47109	regular	Расскажите, что вы любите есть и какую кухню предпочитаете.	1
d8be5bd1-5e73-43e0-98dd-a1c61c101082	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	text	Мой обычный день	Расскажите, как проходит ваш обычный день.	\N	A2	30	120	t	2026-07-04 15:37:13.895622+00	2026-07-05 12:23:20.969818+00	Быт	Утром я встаю в семь часов, завтракаю и иду на работу. Днём я работаю и обедаю с коллегами. Вечером я возвращаюсь домой, ужинаю и отдыхаю.	f	f	3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	regular	Опишите свой обычный день по порядку: утро, день, вечер.	1
436b1878-65ab-4711-81fa-64d9dfbae545	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	text	Планы на выходные	Какие у вас планы на выходные?	\N	B1	30	120	t	2026-07-04 15:37:13.895622+00	2026-07-05 12:23:23.905796+00	Досуг	В эти выходные я хочу отдохнуть. В субботу встречусь с друзьями, а в воскресенье поеду за город. Думаю, будет здорово.	f	t	3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	live	Расскажите о планах на выходные: что, где, с кем.	3
85e60dda-c33d-4964-a0b2-cd70471283a2	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	text	Еда и вкусы	Расскажите о вашей любимой еде.	\N	A2	30	120	t	2026-07-04 15:37:13.895622+00	2026-07-05 12:23:28.209431+00	Еда	Я очень люблю плов и домашнюю еду. Ещё мне нравится итальянская кухня, особенно паста. А вот острое я почти не ем.	f	t	3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	regular	Расскажите, что вы любите есть и какую кухню предпочитаете.	0
fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	f604d00d-599b-434e-8535-d069cccac127	text	Расскажите о себе	Расскажите немного о себе.	\N	A1	30	120	t	2026-07-04 15:37:13.997975+00	2026-07-04 15:37:13.997975+00	Знакомство	Меня зовут Анвар, мне двадцать лет. Я студент, учусь в университете. В свободное время я люблю читать и гулять.	f	f	8cacb3b1-9440-4891-a007-e2781e878e81	regular	Представьтесь: имя, возраст, чем занимаетесь. 3–4 предложения.	0
9b0540c0-82dd-473c-b648-5f3abf3af39c	f604d00d-599b-434e-8535-d069cccac127	text	Мой обычный день	Расскажите, как проходит ваш обычный день.	\N	A2	30	120	t	2026-07-04 15:37:13.997975+00	2026-07-04 15:37:13.997975+00	Быт	Утром я встаю в семь часов, завтракаю и иду на работу. Днём я работаю и обедаю с коллегами. Вечером я возвращаюсь домой, ужинаю и отдыхаю.	f	f	9be2cecd-0812-4d4f-8f54-67e1038b2c7e	regular	Опишите свой обычный день по порядку: утро, день, вечер.	1
925d5cf5-25a1-4be0-9f96-b76ab91f38a1	f604d00d-599b-434e-8535-d069cccac127	text	Любимое место в городе	Опишите ваше любимое место в городе.	\N	B1	30	120	t	2026-07-04 15:37:13.997975+00	2026-07-04 15:37:13.997975+00	Город	Больше всего я люблю старый парк в центре. Там тихо, много зелени, и можно спокойно посидеть. Я часто хожу туда с друзьями по выходным.	f	f	8cacb3b1-9440-4891-a007-e2781e878e81	live	Расскажите о любимом месте в городе и почему оно вам нравится.	2
b6660068-7285-4587-aeee-cbd6ee32cf82	f604d00d-599b-434e-8535-d069cccac127	text	Планы на выходные	Какие у вас планы на выходные?	\N	B1	30	120	t	2026-07-04 15:37:13.997975+00	2026-07-04 15:37:13.997975+00	Досуг	В эти выходные я хочу отдохнуть. В субботу встречусь с друзьями, а в воскресенье поеду за город. Думаю, будет здорово.	f	t	9be2cecd-0812-4d4f-8f54-67e1038b2c7e	live	Расскажите о планах на выходные: что, где, с кем.	3
4b516865-9bc6-45f7-b38f-5798c7f538b1	57917a22-78cf-497e-94bb-a4813c056f6f	text	Расскажите о себе	Расскажите немного о себе.	\N	A1	30	120	t	2026-07-04 15:37:14.028533+00	2026-07-04 15:37:14.028533+00	Знакомство	Меня зовут Анвар, мне двадцать лет. Я студент, учусь в университете. В свободное время я люблю читать и гулять.	f	f	9b779ffc-3316-4306-bde0-11e4f0a163b5	regular	Представьтесь: имя, возраст, чем занимаетесь. 3–4 предложения.	0
802b412a-e6cd-4256-ab70-9adf3bb83a9e	57917a22-78cf-497e-94bb-a4813c056f6f	text	Мой обычный день	Расскажите, как проходит ваш обычный день.	\N	A2	30	120	t	2026-07-04 15:37:14.028533+00	2026-07-04 15:37:14.028533+00	Быт	Утром я встаю в семь часов, завтракаю и иду на работу. Днём я работаю и обедаю с коллегами. Вечером я возвращаюсь домой, ужинаю и отдыхаю.	f	f	6034fda4-ce2c-4b65-9f29-9f35bb9e4242	regular	Опишите свой обычный день по порядку: утро, день, вечер.	1
618daf8d-9b50-410e-9d6f-95034e3291c5	57917a22-78cf-497e-94bb-a4813c056f6f	text	Любимое место в городе	Опишите ваше любимое место в городе.	\N	B1	30	120	t	2026-07-04 15:37:14.028533+00	2026-07-04 15:37:14.028533+00	Город	Больше всего я люблю старый парк в центре. Там тихо, много зелени, и можно спокойно посидеть. Я часто хожу туда с друзьями по выходным.	f	f	9b779ffc-3316-4306-bde0-11e4f0a163b5	live	Расскажите о любимом месте в городе и почему оно вам нравится.	2
1176f594-6b2f-4b71-98c7-95736ab1d5c8	57917a22-78cf-497e-94bb-a4813c056f6f	text	Планы на выходные	Какие у вас планы на выходные?	\N	B1	30	120	t	2026-07-04 15:37:14.028533+00	2026-07-04 15:37:14.028533+00	Досуг	В эти выходные я хочу отдохнуть. В субботу встречусь с друзьями, а в воскресенье поеду за город. Думаю, будет здорово.	f	t	6034fda4-ce2c-4b65-9f29-9f35bb9e4242	live	Расскажите о планах на выходные: что, где, с кем.	3
10dda6f5-02d9-4759-9a89-056a9492075c	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	text	Любимое место в городе	Опишите ваше любимое место в городе.	\N	B1	30	120	t	2026-07-04 15:37:13.895622+00	2026-07-04 15:49:14.966111+00	Город	Больше всего я люблю старый парк в центре. Там тихо, много зелени, и можно спокойно посидеть. Я часто хожу туда с друзьями по выходным.	f	f	3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	live	Расскажите о любимом месте в городе и почему оно вам нравится.	0
6e680d59-567f-4acd-8c7c-94ec549ac5d4	8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	text	Расскажите о себе	Расскажите немного о себе.	\N	A1	30	120	t	2026-07-04 15:37:13.895622+00	2026-07-04 15:49:14.966111+00	Знакомство	Меня зовут Анвар, мне двадцать лет. Я студент, учусь в университете. В свободное время я люблю читать и гулять.	f	f	3b8ca8fc-858e-4e6b-89ad-3fc0e1356edf	regular	Представьтесь: имя, возраст, чем занимаетесь. 3–4 предложения.	1
cc98eecf-5cc4-4e62-89d2-14f712187eb0	656f43bd-8532-481b-bc31-aed8cb9abaad	text	Еда и вкусы	Расскажите о вашей любимой еде.	\N	A2	30	120	t	2026-07-04 15:37:13.969101+00	2026-07-04 15:37:13.969101+00	Еда	Я очень люблю плов и домашнюю еду. Ещё мне нравится итальянская кухня, особенно паста. А вот острое я почти не ем.	f	t	e931dac3-115d-4083-9029-c40e9ea47109	regular	Расскажите, что вы любите есть и какую кухню предпочитаете.	2
4026168a-4225-4b1d-9d24-02600e37775e	f604d00d-599b-434e-8535-d069cccac127	text	Еда и вкусы	Расскажите о вашей любимой еде.	\N	A2	30	120	t	2026-07-04 15:37:13.997975+00	2026-07-04 15:37:13.997975+00	Еда	Я очень люблю плов и домашнюю еду. Ещё мне нравится итальянская кухня, особенно паста. А вот острое я почти не ем.	f	t	e931dac3-115d-4083-9029-c40e9ea47109	regular	Расскажите, что вы любите есть и какую кухню предпочитаете.	3
ae4c2325-a11c-4def-9408-71db92c21f26	57917a22-78cf-497e-94bb-a4813c056f6f	text	Еда и вкусы	Расскажите о вашей любимой еде.	\N	A2	30	120	t	2026-07-04 15:37:14.028533+00	2026-07-04 15:37:14.028533+00	Еда	Я очень люблю плов и домашнюю еду. Ещё мне нравится итальянская кухня, особенно паста. А вот острое я почти не ем.	f	t	e931dac3-115d-4083-9029-c40e9ea47109	regular	Расскажите, что вы любите есть и какую кухню предпочитаете.	4
\.


--
-- Data for Name: review_items; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.review_items (id, student_id, question_id, weakness_dim, interval_index, due_at, completed, created_at, updated_at) FROM stdin;
1526d96d-7c1a-46b6-a50c-d053e5182394	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	4026168a-4225-4b1d-9d24-02600e37775e	relevance	0	2026-07-10 05:25:45.334249+00	t	2026-07-09 05:25:45.330366+00	2026-07-09 05:39:09.438185+00
fdec5e4f-a3e8-42c4-b2a2-55aa52db440d	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	4026168a-4225-4b1d-9d24-02600e37775e	grammar	0	2026-07-10 05:39:09.442439+00	f	2026-07-09 05:39:09.438185+00	2026-07-09 05:39:09.438185+00
\.


--
-- Data for Name: shadowing_phrases; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.shadowing_phrases (id, created_by, text, level, is_active, created_at, updated_at) FROM stdin;
b61cf250-951d-4864-9bba-b706ad1fd881	\N	Привет! Меня зовут Анна.	A1–A2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
58a4e019-6223-485d-aae8-648a8e5ad9e6	\N	Сегодня хорошая погода.	A1–A2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
91e272a3-81c4-4136-8341-d8b007efde03	\N	Я люблю читать книги.	A1–A2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
1698b443-a326-496d-aad4-aefdd4411f15	\N	Где находится библиотека?	A1–A2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
e36698bb-e5ee-4cfc-b6d8-ed153ac32527	\N	Мне нравится русская музыка.	A1–A2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
338e2fef-44ef-4925-bdc3-afdf0a08932b	\N	Вчера я ходил в кино с друзьями.	B1–B2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
a211134d-8b05-4c35-b644-39a2678343aa	\N	Мне кажется, что это очень интересный вопрос.	B1–B2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
26ce06f3-c739-4267-9ca8-cf7b2afdf687	\N	Если будет время, я обязательно тебе позвоню.	B1–B2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
f0b4157d-8fb0-41ac-90be-665dcf62a02f	\N	Этот город известен своей красивой архитектурой.	B1–B2	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
ff2cd275-a634-481a-b7cc-9eb76a8847e7	\N	Несмотря на трудности, мы продолжали работать над проектом.	C1	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
089c50c3-24fe-493e-af5f-d884ab96ee38	\N	Чем больше я узнаю, тем больше понимаю, как мало знаю.	C1	t	2026-07-03 12:36:56.437021+00	2026-07-03 12:36:56.437021+00
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.submissions (id, student_id, question_id, audio_key, audio_duration_sec, status, error_message, completed_at, created_at, updated_at, teacher_comment, teacher_band, reviewed_by, reviewed_at, reference_text, assignment_id, model_answer_text) FROM stdin;
0edd8fb7-d6fd-4f96-9d3a-cae4cfe1d7da	607e5ea6-022e-4fee-b012-78a186ca42c0	6e680d59-567f-4acd-8c7c-94ec549ac5d4	demo/607e5ea6-022e-4fee-b012-78a186ca42c0/6e680d59-567f-4acd-8c7c-94ec549ac5d4.webm	88.9	done	\N	2026-07-01 11:37:13.866395+00	2026-07-01 11:37:13.866395+00	2026-07-04 15:37:13.905432+00	\N	\N	\N	\N	\N	76efcbe2-3fd5-4f11-a825-aa9515d84251	\N
54d45ccc-ad23-41c1-9171-22fb4b9e785e	607e5ea6-022e-4fee-b012-78a186ca42c0	85e60dda-c33d-4964-a0b2-cd70471283a2	demo/607e5ea6-022e-4fee-b012-78a186ca42c0/85e60dda-c33d-4964-a0b2-cd70471283a2.webm	70.4	done	\N	2026-07-01 08:37:13.866395+00	2026-07-01 08:37:13.866395+00	2026-07-04 15:37:13.905432+00	\N	\N	\N	\N	\N	\N	\N
3f43c22e-cbdb-44bb-a828-5f553b3eedb2	607e5ea6-022e-4fee-b012-78a186ca42c0	10dda6f5-02d9-4759-9a89-056a9492075c	demo/607e5ea6-022e-4fee-b012-78a186ca42c0/10dda6f5-02d9-4759-9a89-056a9492075c.webm	94.8	done	\N	2026-06-25 07:37:13.866395+00	2026-06-25 07:37:13.866395+00	2026-07-04 15:37:13.905432+00	\N	\N	\N	\N	\N	\N	\N
4d836253-0a6a-40df-b086-3e6318281c44	607e5ea6-022e-4fee-b012-78a186ca42c0	d8be5bd1-5e73-43e0-98dd-a1c61c101082	demo/607e5ea6-022e-4fee-b012-78a186ca42c0/d8be5bd1-5e73-43e0-98dd-a1c61c101082.webm	37.4	done	\N	2026-06-29 12:37:13.866395+00	2026-06-29 12:37:13.866395+00	2026-07-04 15:37:13.905432+00	\N	\N	\N	\N	\N	bbac2400-f3ea-440f-8a29-ef9f7d38d1d5	\N
e42cb28b-7ffc-4a3f-9610-2e3e73f428e4	607e5ea6-022e-4fee-b012-78a186ca42c0	436b1878-65ab-4711-81fa-64d9dfbae545	demo/607e5ea6-022e-4fee-b012-78a186ca42c0/436b1878-65ab-4711-81fa-64d9dfbae545.webm	107.8	done	\N	2026-06-26 12:37:13.866395+00	2026-06-26 12:37:13.866395+00	2026-07-04 15:37:13.905432+00	\N	\N	\N	\N	\N	\N	\N
71a0dd5e-fca5-4458-a856-4e68777b43de	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	6e680d59-567f-4acd-8c7c-94ec549ac5d4	demo/98e7b29c-43bd-4e5d-b56a-c3cd680d16e4/6e680d59-567f-4acd-8c7c-94ec549ac5d4.webm	99.3	done	\N	2026-07-03 08:37:13.866395+00	2026-07-03 08:37:13.866395+00	2026-07-04 15:37:13.914893+00	\N	\N	\N	\N	\N	4b4b46f1-6a26-4e68-beca-92b3fb06ce20	\N
f756aacb-5f37-473e-a451-d374bc40ab16	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	85e60dda-c33d-4964-a0b2-cd70471283a2	demo/98e7b29c-43bd-4e5d-b56a-c3cd680d16e4/85e60dda-c33d-4964-a0b2-cd70471283a2.webm	86.1	done	\N	2026-06-24 07:37:13.866395+00	2026-06-24 07:37:13.866395+00	2026-07-04 15:37:13.914893+00	\N	\N	\N	\N	\N	\N	\N
7ffc76f7-0ac4-43e7-9fea-de41ff0f5bd2	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	10dda6f5-02d9-4759-9a89-056a9492075c	demo/98e7b29c-43bd-4e5d-b56a-c3cd680d16e4/10dda6f5-02d9-4759-9a89-056a9492075c.webm	51.6	done	\N	2026-06-27 03:37:13.866395+00	2026-06-27 03:37:13.866395+00	2026-07-04 15:37:13.914893+00	\N	\N	\N	\N	\N	\N	\N
495f9102-c7d9-42b9-b358-aa3884aa4b25	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	436b1878-65ab-4711-81fa-64d9dfbae545	demo/98e7b29c-43bd-4e5d-b56a-c3cd680d16e4/436b1878-65ab-4711-81fa-64d9dfbae545.webm	95.7	done	\N	2026-07-04 08:37:13.866395+00	2026-07-04 08:37:13.866395+00	2026-07-04 15:37:13.914893+00	\N	\N	\N	\N	\N	\N	\N
98bd9179-d490-416a-97bc-1a7390026fde	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	d8be5bd1-5e73-43e0-98dd-a1c61c101082	demo/98e7b29c-43bd-4e5d-b56a-c3cd680d16e4/d8be5bd1-5e73-43e0-98dd-a1c61c101082.webm	82.4	done	\N	2026-06-29 09:37:13.866395+00	2026-06-29 09:37:13.866395+00	2026-07-04 15:37:13.914893+00	\N	\N	\N	\N	\N	714ec589-a0f6-497f-948d-a6487b401b62	\N
f90a1068-a5e3-49fb-ad2f-0df9e0b11940	9000ce1c-4db1-499a-a465-34edcabe7f1b	10dda6f5-02d9-4759-9a89-056a9492075c	demo/9000ce1c-4db1-499a-a465-34edcabe7f1b/10dda6f5-02d9-4759-9a89-056a9492075c.webm	70.8	done	\N	2026-07-01 11:37:13.866395+00	2026-07-01 11:37:13.866395+00	2026-07-04 15:37:13.920389+00	\N	\N	\N	\N	\N	\N	\N
d5bcba45-e4cf-4c88-b53f-87e80a3ccebd	9000ce1c-4db1-499a-a465-34edcabe7f1b	436b1878-65ab-4711-81fa-64d9dfbae545	demo/9000ce1c-4db1-499a-a465-34edcabe7f1b/436b1878-65ab-4711-81fa-64d9dfbae545.webm	35.1	done	\N	2026-06-27 20:37:13.866395+00	2026-06-27 20:37:13.866395+00	2026-07-04 15:37:13.920389+00	\N	\N	\N	\N	\N	\N	\N
9263acef-c8cd-4602-a47d-58f87d55cce5	9000ce1c-4db1-499a-a465-34edcabe7f1b	85e60dda-c33d-4964-a0b2-cd70471283a2	demo/9000ce1c-4db1-499a-a465-34edcabe7f1b/85e60dda-c33d-4964-a0b2-cd70471283a2.webm	84.5	done	\N	2026-07-04 12:37:13.866395+00	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.920389+00	\N	\N	\N	\N	\N	\N	\N
6cfca392-aba9-410b-9a34-a3d45ea95b51	9000ce1c-4db1-499a-a465-34edcabe7f1b	d8be5bd1-5e73-43e0-98dd-a1c61c101082	demo/9000ce1c-4db1-499a-a465-34edcabe7f1b/d8be5bd1-5e73-43e0-98dd-a1c61c101082.webm	106.3	done	\N	2026-06-27 15:37:13.866395+00	2026-06-27 15:37:13.866395+00	2026-07-04 15:37:13.920389+00	\N	\N	\N	\N	\N	c9dde59a-5b72-4079-bf71-4d7826cf02bc	\N
5225ae61-40e1-4a32-815f-4d2641f7d065	9000ce1c-4db1-499a-a465-34edcabe7f1b	6e680d59-567f-4acd-8c7c-94ec549ac5d4	demo/9000ce1c-4db1-499a-a465-34edcabe7f1b/6e680d59-567f-4acd-8c7c-94ec549ac5d4.webm	97.3	done	\N	2026-06-24 06:37:13.866395+00	2026-06-24 06:37:13.866395+00	2026-07-04 15:37:13.920389+00	\N	\N	\N	\N	\N	0ac1cb82-091b-4eca-a417-24bec95fadd5	\N
9ca9d239-bd66-40de-8ee0-5ef980545bfe	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	85e60dda-c33d-4964-a0b2-cd70471283a2	demo/b578f40c-4b35-40c3-b1d4-e8520a8ba23b/85e60dda-c33d-4964-a0b2-cd70471283a2.webm	104.3	done	\N	2026-07-04 12:37:13.866395+00	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.925356+00	\N	\N	\N	\N	\N	\N	\N
83d77585-5719-44b0-ac59-f6977e014e6c	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	10dda6f5-02d9-4759-9a89-056a9492075c	demo/b578f40c-4b35-40c3-b1d4-e8520a8ba23b/10dda6f5-02d9-4759-9a89-056a9492075c.webm	88.6	done	\N	2026-07-03 13:37:13.866395+00	2026-07-03 13:37:13.866395+00	2026-07-04 15:37:13.925356+00	\N	\N	\N	\N	\N	\N	\N
ce21e2a4-781d-40b6-af08-293ec290d2ef	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	d8be5bd1-5e73-43e0-98dd-a1c61c101082	demo/b578f40c-4b35-40c3-b1d4-e8520a8ba23b/d8be5bd1-5e73-43e0-98dd-a1c61c101082.webm	51.2	done	\N	2026-06-26 10:37:13.866395+00	2026-06-26 10:37:13.866395+00	2026-07-04 15:37:13.925356+00	\N	\N	\N	\N	\N	cdd1439a-4dc1-4404-bfd9-05770c8d14b7	\N
2b9a4f94-cdb6-432e-bc8b-24e1994aea14	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	10dda6f5-02d9-4759-9a89-056a9492075c	demo/bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85/10dda6f5-02d9-4759-9a89-056a9492075c.webm	39.7	done	\N	2026-06-26 01:37:13.866395+00	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:13.928285+00	\N	\N	\N	\N	\N	\N	\N
0bb4e935-9c4b-4b45-af31-58f4a31641b2	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	436b1878-65ab-4711-81fa-64d9dfbae545	demo/bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85/436b1878-65ab-4711-81fa-64d9dfbae545.webm	34.7	done	\N	2026-07-02 19:37:13.866395+00	2026-07-02 19:37:13.866395+00	2026-07-04 15:37:13.928285+00	\N	\N	\N	\N	\N	\N	\N
d8612cb3-1555-4dbc-841b-105785ec214d	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	85e60dda-c33d-4964-a0b2-cd70471283a2	demo/bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85/85e60dda-c33d-4964-a0b2-cd70471283a2.webm	73.1	done	\N	2026-06-27 09:37:13.866395+00	2026-06-27 09:37:13.866395+00	2026-07-04 15:37:13.928285+00	\N	\N	\N	\N	\N	\N	\N
94dca90e-6adc-4e44-ab6d-7266c1b4129d	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	d8be5bd1-5e73-43e0-98dd-a1c61c101082	demo/bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85/d8be5bd1-5e73-43e0-98dd-a1c61c101082.webm	37.5	done	\N	2026-06-28 09:37:13.866395+00	2026-06-28 09:37:13.866395+00	2026-07-04 15:37:13.928285+00	\N	\N	\N	\N	\N	2bb50e33-7b57-4784-af4e-52e885642adf	\N
cea5aa89-43dd-4fbf-bdf6-668d3d3fbcdb	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	6e680d59-567f-4acd-8c7c-94ec549ac5d4	demo/bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85/6e680d59-567f-4acd-8c7c-94ec549ac5d4.webm	37.9	done	\N	2026-06-23 19:37:13.866395+00	2026-06-23 19:37:13.866395+00	2026-07-04 15:37:13.928285+00	\N	\N	\N	\N	\N	a3aaca3c-e79f-4a23-a6f6-b6f1c1aa4647	\N
e83bfa36-844d-4100-a358-0794d8e1b38f	6832d92c-b0ef-490d-805c-98cbd726f198	aaa0a816-6a6f-4a5b-9d63-9d470931775f	demo/6832d92c-b0ef-490d-805c-98cbd726f198/aaa0a816-6a6f-4a5b-9d63-9d470931775f.webm	100	done	\N	2026-06-27 08:37:13.866395+00	2026-06-27 08:37:13.866395+00	2026-07-04 15:37:13.944695+00	\N	\N	\N	\N	\N	\N	\N
5e3289f7-48bf-47d8-b6a1-73cf4a201935	6832d92c-b0ef-490d-805c-98cbd726f198	4710821b-14cd-43c0-848a-68798c90df4f	demo/6832d92c-b0ef-490d-805c-98cbd726f198/4710821b-14cd-43c0-848a-68798c90df4f.webm	107.5	done	\N	2026-06-26 15:37:13.866395+00	2026-06-26 15:37:13.866395+00	2026-07-04 15:37:13.944695+00	\N	\N	\N	\N	\N	dfb6bff9-1f37-449d-8b04-b218c115b598	\N
7e1721fd-8c95-44ff-b0c5-3b2d9b8877ab	6832d92c-b0ef-490d-805c-98cbd726f198	0ded0323-938f-4e21-a5a5-15dd71b29e1b	demo/6832d92c-b0ef-490d-805c-98cbd726f198/0ded0323-938f-4e21-a5a5-15dd71b29e1b.webm	43.2	done	\N	2026-06-28 14:37:13.866395+00	2026-06-28 14:37:13.866395+00	2026-07-04 15:37:13.944695+00	\N	\N	\N	\N	\N	\N	\N
16c1a37b-293b-4906-a5f6-98a76614d0b4	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	aaa0a816-6a6f-4a5b-9d63-9d470931775f	demo/a8c7fcc3-947f-421d-ad5a-a2d6cd448977/aaa0a816-6a6f-4a5b-9d63-9d470931775f.webm	88.9	done	\N	2026-07-03 21:37:13.866395+00	2026-07-03 21:37:13.866395+00	2026-07-04 15:37:13.948024+00	\N	\N	\N	\N	\N	\N	\N
9ffd376c-ae9f-4d8f-85c8-dc4a9bd4d2c9	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	4710821b-14cd-43c0-848a-68798c90df4f	demo/a8c7fcc3-947f-421d-ad5a-a2d6cd448977/4710821b-14cd-43c0-848a-68798c90df4f.webm	34.6	done	\N	2026-06-26 10:37:13.866395+00	2026-06-26 10:37:13.866395+00	2026-07-04 15:37:13.948024+00	\N	\N	\N	\N	\N	56786b4e-aecc-4946-b1c8-6a2e7c68bc3d	\N
8f40f70d-462d-4721-9ac9-a48651706869	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	demo/a8c7fcc3-947f-421d-ad5a-a2d6cd448977/2025cbb7-64c5-4ed4-abbf-f2229bb1b23b.webm	105.3	done	\N	2026-06-28 12:37:13.866395+00	2026-06-28 12:37:13.866395+00	2026-07-04 15:37:13.948024+00	\N	\N	\N	\N	\N	00e983de-0dea-47c7-b47d-e8d223210017	\N
a0c23ea8-77bc-4eff-902c-158bf503b9ff	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	0ded0323-938f-4e21-a5a5-15dd71b29e1b	demo/a8c7fcc3-947f-421d-ad5a-a2d6cd448977/0ded0323-938f-4e21-a5a5-15dd71b29e1b.webm	55.3	done	\N	2026-06-24 23:37:13.866395+00	2026-06-24 23:37:13.866395+00	2026-07-04 15:37:13.948024+00	\N	\N	\N	\N	\N	\N	\N
91f2163f-8848-4700-bb02-cda2410227ec	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	27acb5c7-3e03-4ec1-9650-ba979fbc4066	demo/a8c7fcc3-947f-421d-ad5a-a2d6cd448977/27acb5c7-3e03-4ec1-9650-ba979fbc4066.webm	66.6	done	\N	2026-06-24 06:37:13.866395+00	2026-06-24 06:37:13.866395+00	2026-07-04 15:37:13.948024+00	\N	\N	\N	\N	\N	\N	\N
9884e60a-3824-4c5b-87ff-21e3392bd679	662b71e8-b41e-4198-a07c-9fdb8288e651	0ded0323-938f-4e21-a5a5-15dd71b29e1b	demo/662b71e8-b41e-4198-a07c-9fdb8288e651/0ded0323-938f-4e21-a5a5-15dd71b29e1b.webm	104.7	done	\N	2026-06-30 11:37:13.866395+00	2026-06-30 11:37:13.866395+00	2026-07-04 15:37:13.953035+00	\N	\N	\N	\N	\N	\N	\N
216f4459-017f-44f8-a396-c347c10aeb7e	662b71e8-b41e-4198-a07c-9fdb8288e651	4710821b-14cd-43c0-848a-68798c90df4f	demo/662b71e8-b41e-4198-a07c-9fdb8288e651/4710821b-14cd-43c0-848a-68798c90df4f.webm	108.7	done	\N	2026-06-29 20:37:13.866395+00	2026-06-29 20:37:13.866395+00	2026-07-04 15:37:13.953035+00	\N	\N	\N	\N	\N	124cd276-12a8-41b6-8fb3-b344190c6528	\N
1764a08c-5437-4934-8c36-4a52fe8be50f	662b71e8-b41e-4198-a07c-9fdb8288e651	27acb5c7-3e03-4ec1-9650-ba979fbc4066	demo/662b71e8-b41e-4198-a07c-9fdb8288e651/27acb5c7-3e03-4ec1-9650-ba979fbc4066.webm	51.2	done	\N	2026-07-03 11:37:13.866395+00	2026-07-03 11:37:13.866395+00	2026-07-04 15:37:13.953035+00	\N	\N	\N	\N	\N	\N	\N
f69940b2-96fa-4e98-bfbb-014af377cf43	99bff3a0-8237-4afd-bd58-937faf6cbaae	27acb5c7-3e03-4ec1-9650-ba979fbc4066	demo/99bff3a0-8237-4afd-bd58-937faf6cbaae/27acb5c7-3e03-4ec1-9650-ba979fbc4066.webm	80.7	done	\N	2026-07-04 13:37:13.866395+00	2026-07-04 13:37:13.866395+00	2026-07-04 15:37:13.956359+00	\N	\N	\N	\N	\N	\N	\N
4f1a70dd-699f-47f9-9249-4d9159ff1779	99bff3a0-8237-4afd-bd58-937faf6cbaae	aaa0a816-6a6f-4a5b-9d63-9d470931775f	demo/99bff3a0-8237-4afd-bd58-937faf6cbaae/aaa0a816-6a6f-4a5b-9d63-9d470931775f.webm	74.1	done	\N	2026-07-02 01:37:13.866395+00	2026-07-02 01:37:13.866395+00	2026-07-04 15:37:13.956359+00	\N	\N	\N	\N	\N	\N	\N
6ced6c01-eed9-427f-a03f-15aa27cb6b28	99bff3a0-8237-4afd-bd58-937faf6cbaae	4710821b-14cd-43c0-848a-68798c90df4f	demo/99bff3a0-8237-4afd-bd58-937faf6cbaae/4710821b-14cd-43c0-848a-68798c90df4f.webm	96.8	done	\N	2026-06-26 14:37:13.866395+00	2026-06-26 14:37:13.866395+00	2026-07-04 15:37:13.956359+00	\N	\N	\N	\N	\N	806c488d-2fb9-49b7-82f7-5f107e943f75	\N
66a1d5b4-7907-4b3a-88ad-fb78cea62395	b584e81c-08dd-4f1f-b181-6e02de1214b0	4710821b-14cd-43c0-848a-68798c90df4f	demo/b584e81c-08dd-4f1f-b181-6e02de1214b0/4710821b-14cd-43c0-848a-68798c90df4f.webm	100.7	done	\N	2026-06-28 22:37:13.866395+00	2026-06-28 22:37:13.866395+00	2026-07-04 15:37:13.95938+00	\N	\N	\N	\N	\N	dfd26193-dab7-4265-b480-be3c59b567b2	\N
95b44407-9a6e-4115-b18e-3dcaf8fd54c3	b584e81c-08dd-4f1f-b181-6e02de1214b0	0ded0323-938f-4e21-a5a5-15dd71b29e1b	demo/b584e81c-08dd-4f1f-b181-6e02de1214b0/0ded0323-938f-4e21-a5a5-15dd71b29e1b.webm	32	done	\N	2026-07-02 02:37:13.866395+00	2026-07-02 02:37:13.866395+00	2026-07-04 15:37:13.95938+00	\N	\N	\N	\N	\N	\N	\N
5f4ebf45-1bfe-475c-a858-6ac668d5171f	b584e81c-08dd-4f1f-b181-6e02de1214b0	27acb5c7-3e03-4ec1-9650-ba979fbc4066	demo/b584e81c-08dd-4f1f-b181-6e02de1214b0/27acb5c7-3e03-4ec1-9650-ba979fbc4066.webm	42.7	done	\N	2026-07-01 07:37:13.866395+00	2026-07-01 07:37:13.866395+00	2026-07-04 15:37:13.95938+00	\N	\N	\N	\N	\N	\N	\N
d73fb91d-6a83-4158-9356-9a49ef6447d2	b584e81c-08dd-4f1f-b181-6e02de1214b0	2025cbb7-64c5-4ed4-abbf-f2229bb1b23b	demo/b584e81c-08dd-4f1f-b181-6e02de1214b0/2025cbb7-64c5-4ed4-abbf-f2229bb1b23b.webm	54.4	done	\N	2026-06-27 04:37:13.866395+00	2026-06-27 04:37:13.866395+00	2026-07-04 15:37:13.95938+00	\N	\N	\N	\N	\N	545248e3-456b-431c-b72b-8ea42fefe1de	\N
45673d97-c4d0-4680-9bc5-665e72a7995e	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	aaebe5d0-90df-47a6-8c73-42deb6f8faef	demo/b3d8a2a1-32bb-4694-9a0f-4c2758594ec7/aaebe5d0-90df-47a6-8c73-42deb6f8faef.webm	100.2	done	\N	2026-07-04 12:37:13.866395+00	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.974962+00	\N	\N	\N	\N	\N	\N	\N
f61fde7d-326d-4462-a5ff-ef66df54d9e7	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	4771b3c0-458c-4d18-ba64-eb023c273e88	demo/b3d8a2a1-32bb-4694-9a0f-4c2758594ec7/4771b3c0-458c-4d18-ba64-eb023c273e88.webm	64.9	done	\N	2026-06-29 05:37:13.866395+00	2026-06-29 05:37:13.866395+00	2026-07-04 15:37:13.974962+00	\N	\N	\N	\N	\N	\N	\N
09a5bf13-99a0-42e5-97dd-1012a92b88f6	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	cc98eecf-5cc4-4e62-89d2-14f712187eb0	demo/b3d8a2a1-32bb-4694-9a0f-4c2758594ec7/cc98eecf-5cc4-4e62-89d2-14f712187eb0.webm	71.6	done	\N	2026-06-28 15:37:13.866395+00	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.974962+00	\N	\N	\N	\N	\N	\N	\N
6e76bbb7-54ee-4662-97c6-aaabec0462b5	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	cc92ed85-1500-4364-a12e-00e891ff6916	demo/b3d8a2a1-32bb-4694-9a0f-4c2758594ec7/cc92ed85-1500-4364-a12e-00e891ff6916.webm	105.9	done	\N	2026-06-28 13:37:13.866395+00	2026-06-28 13:37:13.866395+00	2026-07-04 15:37:13.974962+00	\N	\N	\N	\N	\N	2d58c2cc-d226-4922-9598-347fc03372db	\N
fede438b-b7c4-4ae1-a583-e09bf7214c41	6f394335-b63b-4c72-b929-78733facb505	4771b3c0-458c-4d18-ba64-eb023c273e88	demo/6f394335-b63b-4c72-b929-78733facb505/4771b3c0-458c-4d18-ba64-eb023c273e88.webm	45.3	done	\N	2026-06-26 11:37:13.866395+00	2026-06-26 11:37:13.866395+00	2026-07-04 15:37:13.978905+00	\N	\N	\N	\N	\N	\N	\N
6cea0ca9-3583-429e-8102-a5a4fd364193	6f394335-b63b-4c72-b929-78733facb505	aaebe5d0-90df-47a6-8c73-42deb6f8faef	demo/6f394335-b63b-4c72-b929-78733facb505/aaebe5d0-90df-47a6-8c73-42deb6f8faef.webm	96.7	done	\N	2026-06-27 22:37:13.866395+00	2026-06-27 22:37:13.866395+00	2026-07-04 15:37:13.978905+00	\N	\N	\N	\N	\N	\N	\N
768cfd45-f415-46cb-86f0-c1e3f4d96671	6f394335-b63b-4c72-b929-78733facb505	cc92ed85-1500-4364-a12e-00e891ff6916	demo/6f394335-b63b-4c72-b929-78733facb505/cc92ed85-1500-4364-a12e-00e891ff6916.webm	84.1	done	\N	2026-06-27 01:37:13.866395+00	2026-06-27 01:37:13.866395+00	2026-07-04 15:37:13.978905+00	\N	\N	\N	\N	\N	c63db93d-21b9-405a-a9e3-e50d5b92df4e	\N
f94ebff4-9fb7-4883-b15a-fb25e3248cb9	6f394335-b63b-4c72-b929-78733facb505	cc98eecf-5cc4-4e62-89d2-14f712187eb0	demo/6f394335-b63b-4c72-b929-78733facb505/cc98eecf-5cc4-4e62-89d2-14f712187eb0.webm	83.1	done	\N	2026-06-29 23:37:13.866395+00	2026-06-29 23:37:13.866395+00	2026-07-04 15:37:13.978905+00	\N	\N	\N	\N	\N	\N	\N
3f0f9ced-e914-42c7-af90-cbab87e325de	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	abd59234-f9c1-47ca-acaa-24e08f9ecf5c	demo/9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b/abd59234-f9c1-47ca-acaa-24e08f9ecf5c.webm	98	done	\N	2026-06-26 20:37:13.866395+00	2026-06-26 20:37:13.866395+00	2026-07-04 15:37:13.982684+00	\N	\N	\N	\N	\N	de1bdb3b-cbff-4768-b44c-3e7102c27410	\N
8c667cad-e6d6-4470-8af7-04e82391ae6e	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	cc98eecf-5cc4-4e62-89d2-14f712187eb0	demo/9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b/cc98eecf-5cc4-4e62-89d2-14f712187eb0.webm	49.5	done	\N	2026-06-27 03:37:13.866395+00	2026-06-27 03:37:13.866395+00	2026-07-04 15:37:13.982684+00	\N	\N	\N	\N	\N	\N	\N
b9238b70-4c37-438d-a88a-aa3ec56c9b71	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	4771b3c0-458c-4d18-ba64-eb023c273e88	demo/9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b/4771b3c0-458c-4d18-ba64-eb023c273e88.webm	44.1	done	\N	2026-06-28 08:37:13.866395+00	2026-06-28 08:37:13.866395+00	2026-07-04 15:37:13.982684+00	\N	\N	\N	\N	\N	\N	\N
31a5ec23-c1e5-4c8c-a4cc-39d17b9d98ab	1f8f0810-c92e-48f5-9bc7-eda00173e390	4771b3c0-458c-4d18-ba64-eb023c273e88	demo/1f8f0810-c92e-48f5-9bc7-eda00173e390/4771b3c0-458c-4d18-ba64-eb023c273e88.webm	64.1	done	\N	2026-06-24 23:37:13.866395+00	2026-06-24 23:37:13.866395+00	2026-07-04 15:37:13.986006+00	\N	\N	\N	\N	\N	\N	\N
4e5e81be-363f-481d-80b5-2430fff7a5ca	1f8f0810-c92e-48f5-9bc7-eda00173e390	aaebe5d0-90df-47a6-8c73-42deb6f8faef	demo/1f8f0810-c92e-48f5-9bc7-eda00173e390/aaebe5d0-90df-47a6-8c73-42deb6f8faef.webm	52.2	done	\N	2026-06-30 19:37:13.866395+00	2026-06-30 19:37:13.866395+00	2026-07-04 15:37:13.986006+00	\N	\N	\N	\N	\N	\N	\N
8e4bb48a-9e44-4c18-ab58-7fe2359df794	1f8f0810-c92e-48f5-9bc7-eda00173e390	cc92ed85-1500-4364-a12e-00e891ff6916	demo/1f8f0810-c92e-48f5-9bc7-eda00173e390/cc92ed85-1500-4364-a12e-00e891ff6916.webm	56.9	done	\N	2026-07-01 07:37:13.866395+00	2026-07-01 07:37:13.866395+00	2026-07-04 15:37:13.986006+00	\N	\N	\N	\N	\N	df92d570-79eb-446f-87cd-f4452c820900	\N
aa72dd02-86f7-4c19-85cb-7b5cae529831	51cfb12f-6865-4891-8342-aec015a5f60c	4771b3c0-458c-4d18-ba64-eb023c273e88	demo/51cfb12f-6865-4891-8342-aec015a5f60c/4771b3c0-458c-4d18-ba64-eb023c273e88.webm	63.3	done	\N	2026-06-26 01:37:13.866395+00	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:13.989101+00	\N	\N	\N	\N	\N	\N	\N
2f47ca19-057d-4980-b3df-1c319a8a2dab	51cfb12f-6865-4891-8342-aec015a5f60c	cc98eecf-5cc4-4e62-89d2-14f712187eb0	demo/51cfb12f-6865-4891-8342-aec015a5f60c/cc98eecf-5cc4-4e62-89d2-14f712187eb0.webm	68.2	done	\N	2026-06-25 03:37:13.866395+00	2026-06-25 03:37:13.866395+00	2026-07-04 15:37:13.989101+00	\N	\N	\N	\N	\N	\N	\N
40eb9350-7635-431e-ae7c-aa753f1e0e9a	51cfb12f-6865-4891-8342-aec015a5f60c	cc92ed85-1500-4364-a12e-00e891ff6916	demo/51cfb12f-6865-4891-8342-aec015a5f60c/cc92ed85-1500-4364-a12e-00e891ff6916.webm	94	done	\N	2026-06-25 22:37:13.866395+00	2026-06-25 22:37:13.866395+00	2026-07-04 15:37:13.989101+00	\N	\N	\N	\N	\N	7b4f79a1-b187-462b-b1bb-a97153bc0384	\N
b23fc5ca-10ac-471e-a2cd-c51adabc7658	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	9b0540c0-82dd-473c-b648-5f3abf3af39c	demo/67e3cbb6-67b6-4750-98bd-c43809d9e5ff/9b0540c0-82dd-473c-b648-5f3abf3af39c.webm	83	done	\N	2026-06-24 21:37:13.866395+00	2026-06-24 21:37:13.866395+00	2026-07-04 15:37:14.003592+00	\N	\N	\N	\N	\N	5d7231a6-e594-462f-b3d2-09af1dedb229	\N
66d09a8f-023b-40c5-9221-59d12805cc2c	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	b6660068-7285-4587-aeee-cbd6ee32cf82	demo/67e3cbb6-67b6-4750-98bd-c43809d9e5ff/b6660068-7285-4587-aeee-cbd6ee32cf82.webm	66.4	done	\N	2026-06-29 09:37:13.866395+00	2026-06-29 09:37:13.866395+00	2026-07-04 15:37:14.003592+00	\N	\N	\N	\N	\N	\N	\N
4bbe2fbb-ce58-4e74-8e36-ffde513b5ad9	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	demo/67e3cbb6-67b6-4750-98bd-c43809d9e5ff/fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf.webm	31.6	done	\N	2026-07-03 00:37:13.866395+00	2026-07-03 00:37:13.866395+00	2026-07-04 15:37:14.003592+00	\N	\N	\N	\N	\N	536a9085-5dd9-49e8-925e-6a8e64c5c1ea	\N
fb4a92cb-afa8-4657-be68-08d63ac9dd2e	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	925d5cf5-25a1-4be0-9f96-b76ab91f38a1	demo/67e3cbb6-67b6-4750-98bd-c43809d9e5ff/925d5cf5-25a1-4be0-9f96-b76ab91f38a1.webm	90.3	done	\N	2026-06-24 14:37:13.866395+00	2026-06-24 14:37:13.866395+00	2026-07-04 15:37:14.003592+00	\N	\N	\N	\N	\N	\N	\N
0b5d5bcf-d14f-4edf-9c29-8b00533bb9de	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	4026168a-4225-4b1d-9d24-02600e37775e	demo/67e3cbb6-67b6-4750-98bd-c43809d9e5ff/4026168a-4225-4b1d-9d24-02600e37775e.webm	75.1	done	\N	2026-06-24 12:37:13.866395+00	2026-06-24 12:37:13.866395+00	2026-07-04 15:37:14.003592+00	\N	\N	\N	\N	\N	\N	\N
09952ee0-3b05-49ef-8db4-519bd3a4b743	13b13315-eb4e-4da6-b645-e558bf78f6db	925d5cf5-25a1-4be0-9f96-b76ab91f38a1	demo/13b13315-eb4e-4da6-b645-e558bf78f6db/925d5cf5-25a1-4be0-9f96-b76ab91f38a1.webm	76.1	done	\N	2026-07-04 06:37:13.866395+00	2026-07-04 06:37:13.866395+00	2026-07-04 15:37:14.008312+00	\N	\N	\N	\N	\N	\N	\N
9018bd1e-547c-4a3f-8199-b78b8f4404e1	13b13315-eb4e-4da6-b645-e558bf78f6db	fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf	demo/13b13315-eb4e-4da6-b645-e558bf78f6db/fe2001e4-9fb6-4447-a6eb-c123d1ec0bbf.webm	38.2	done	\N	2026-06-24 08:37:13.866395+00	2026-06-24 08:37:13.866395+00	2026-07-04 15:37:14.008312+00	\N	\N	\N	\N	\N	a290c405-8cf3-48ab-b35c-9686693d4ac3	\N
48247057-f810-48f7-8cc4-0ac3cff4b84a	13b13315-eb4e-4da6-b645-e558bf78f6db	4026168a-4225-4b1d-9d24-02600e37775e	demo/13b13315-eb4e-4da6-b645-e558bf78f6db/4026168a-4225-4b1d-9d24-02600e37775e.webm	72.6	done	\N	2026-07-04 04:37:13.866395+00	2026-07-04 04:37:13.866395+00	2026-07-04 15:37:14.008312+00	\N	\N	\N	\N	\N	\N	\N
f36ea940-be4f-42e5-846e-419f87f21c02	182470a9-678c-4231-bbbf-41d427773497	b6660068-7285-4587-aeee-cbd6ee32cf82	demo/182470a9-678c-4231-bbbf-41d427773497/b6660068-7285-4587-aeee-cbd6ee32cf82.webm	64.8	done	\N	2026-06-27 11:37:13.866395+00	2026-06-27 11:37:13.866395+00	2026-07-04 15:37:14.011634+00	\N	\N	\N	\N	\N	\N	\N
e10f3719-3b8f-495c-b438-b3c8859e890b	182470a9-678c-4231-bbbf-41d427773497	925d5cf5-25a1-4be0-9f96-b76ab91f38a1	demo/182470a9-678c-4231-bbbf-41d427773497/925d5cf5-25a1-4be0-9f96-b76ab91f38a1.webm	64.8	done	\N	2026-06-27 01:37:13.866395+00	2026-06-27 01:37:13.866395+00	2026-07-04 15:37:14.011634+00	\N	\N	\N	\N	\N	\N	\N
419ec27e-11e0-478f-b62d-791043fd431e	182470a9-678c-4231-bbbf-41d427773497	4026168a-4225-4b1d-9d24-02600e37775e	demo/182470a9-678c-4231-bbbf-41d427773497/4026168a-4225-4b1d-9d24-02600e37775e.webm	90	done	\N	2026-06-27 08:37:13.866395+00	2026-06-27 08:37:13.866395+00	2026-07-04 15:37:14.011634+00	\N	\N	\N	\N	\N	\N	\N
7b39b83e-43cb-440f-88df-b77b00d99a6f	8f73affc-cb6c-4b19-92fc-2337385eb851	925d5cf5-25a1-4be0-9f96-b76ab91f38a1	demo/8f73affc-cb6c-4b19-92fc-2337385eb851/925d5cf5-25a1-4be0-9f96-b76ab91f38a1.webm	86.1	done	\N	2026-06-29 20:37:13.866395+00	2026-06-29 20:37:13.866395+00	2026-07-04 15:37:14.014855+00	\N	\N	\N	\N	\N	\N	\N
755eb452-2de0-4151-bff3-f279c077aea0	8f73affc-cb6c-4b19-92fc-2337385eb851	4026168a-4225-4b1d-9d24-02600e37775e	demo/8f73affc-cb6c-4b19-92fc-2337385eb851/4026168a-4225-4b1d-9d24-02600e37775e.webm	90.7	done	\N	2026-06-26 22:37:13.866395+00	2026-06-26 22:37:13.866395+00	2026-07-04 15:37:14.014855+00	\N	\N	\N	\N	\N	\N	\N
ed953bc7-0e32-4f29-951a-790dcae2b4a1	8f73affc-cb6c-4b19-92fc-2337385eb851	9b0540c0-82dd-473c-b648-5f3abf3af39c	demo/8f73affc-cb6c-4b19-92fc-2337385eb851/9b0540c0-82dd-473c-b648-5f3abf3af39c.webm	85.3	done	\N	2026-07-01 03:37:13.866395+00	2026-07-01 03:37:13.866395+00	2026-07-04 15:37:14.014855+00	\N	\N	\N	\N	\N	da75b3fd-d451-4c41-8763-73cf4753f98f	\N
8b6c5e05-3c6e-40fb-a086-4401c4390637	12b3b088-bdf0-4379-b2a7-aeae73280ea6	925d5cf5-25a1-4be0-9f96-b76ab91f38a1	demo/12b3b088-bdf0-4379-b2a7-aeae73280ea6/925d5cf5-25a1-4be0-9f96-b76ab91f38a1.webm	39.7	done	\N	2026-06-30 08:37:13.866395+00	2026-06-30 08:37:13.866395+00	2026-07-04 15:37:14.018145+00	\N	\N	\N	\N	\N	\N	\N
3083ed90-1c08-43bb-8676-ba214c62916e	12b3b088-bdf0-4379-b2a7-aeae73280ea6	b6660068-7285-4587-aeee-cbd6ee32cf82	demo/12b3b088-bdf0-4379-b2a7-aeae73280ea6/b6660068-7285-4587-aeee-cbd6ee32cf82.webm	52.1	done	\N	2026-07-01 00:37:13.866395+00	2026-07-01 00:37:13.866395+00	2026-07-04 15:37:14.018145+00	\N	\N	\N	\N	\N	\N	\N
a690611f-b1e0-476c-95dd-914648dd1d12	12b3b088-bdf0-4379-b2a7-aeae73280ea6	9b0540c0-82dd-473c-b648-5f3abf3af39c	demo/12b3b088-bdf0-4379-b2a7-aeae73280ea6/9b0540c0-82dd-473c-b648-5f3abf3af39c.webm	58.9	done	\N	2026-06-30 08:37:13.866395+00	2026-06-30 08:37:13.866395+00	2026-07-04 15:37:14.018145+00	\N	\N	\N	\N	\N	90d6edda-ebe0-40ce-a4e6-298855949fd6	\N
e031cbea-392d-4bb6-8053-7f178866c88c	12b3b088-bdf0-4379-b2a7-aeae73280ea6	4026168a-4225-4b1d-9d24-02600e37775e	demo/12b3b088-bdf0-4379-b2a7-aeae73280ea6/4026168a-4225-4b1d-9d24-02600e37775e.webm	81	done	\N	2026-06-30 11:37:13.866395+00	2026-06-30 11:37:13.866395+00	2026-07-04 15:37:14.018145+00	\N	\N	\N	\N	\N	\N	\N
d62885ce-cc8e-4f98-9606-438cd9443325	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	4b516865-9bc6-45f7-b38f-5798c7f538b1	demo/9bf54b62-e54f-47f7-b8b4-9ac54cb5878f/4b516865-9bc6-45f7-b38f-5798c7f538b1.webm	62.1	done	\N	2026-07-03 13:37:13.866395+00	2026-07-03 13:37:13.866395+00	2026-07-04 15:37:14.034497+00	\N	\N	\N	\N	\N	9ce79ce3-d9d4-4c1a-9bf2-6659ae918a16	\N
8dd27d45-c888-436a-b978-4695143b170c	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	618daf8d-9b50-410e-9d6f-95034e3291c5	demo/9bf54b62-e54f-47f7-b8b4-9ac54cb5878f/618daf8d-9b50-410e-9d6f-95034e3291c5.webm	109.5	done	\N	2026-06-30 13:37:13.866395+00	2026-06-30 13:37:13.866395+00	2026-07-04 15:37:14.034497+00	\N	\N	\N	\N	\N	\N	\N
2b4efca5-c485-42d5-9702-46c4bec8c069	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	802b412a-e6cd-4256-ab70-9adf3bb83a9e	demo/9bf54b62-e54f-47f7-b8b4-9ac54cb5878f/802b412a-e6cd-4256-ab70-9adf3bb83a9e.webm	66	done	\N	2026-06-26 03:37:13.866395+00	2026-06-26 03:37:13.866395+00	2026-07-04 15:37:14.034497+00	\N	\N	\N	\N	\N	b7859ef4-9acd-42a8-8993-b0589db96055	\N
c16922f7-8eae-4794-8003-01b25d98ce4f	86df832e-096f-4174-b022-a932fedefca0	802b412a-e6cd-4256-ab70-9adf3bb83a9e	demo/86df832e-096f-4174-b022-a932fedefca0/802b412a-e6cd-4256-ab70-9adf3bb83a9e.webm	49.2	done	\N	2026-07-03 10:37:13.866395+00	2026-07-03 10:37:13.866395+00	2026-07-04 15:37:14.037551+00	\N	\N	\N	\N	\N	04a91731-52df-4a3f-aad6-3eeaf2bdc18d	\N
cf1d1cef-9c87-4628-8948-2d61eceeea95	86df832e-096f-4174-b022-a932fedefca0	618daf8d-9b50-410e-9d6f-95034e3291c5	demo/86df832e-096f-4174-b022-a932fedefca0/618daf8d-9b50-410e-9d6f-95034e3291c5.webm	53	done	\N	2026-07-04 08:37:13.866395+00	2026-07-04 08:37:13.866395+00	2026-07-04 15:37:14.037551+00	\N	\N	\N	\N	\N	\N	\N
c72a58aa-bd06-474c-827c-d79c305d72f5	86df832e-096f-4174-b022-a932fedefca0	1176f594-6b2f-4b71-98c7-95736ab1d5c8	demo/86df832e-096f-4174-b022-a932fedefca0/1176f594-6b2f-4b71-98c7-95736ab1d5c8.webm	82.9	done	\N	2026-06-23 21:37:13.866395+00	2026-06-23 21:37:13.866395+00	2026-07-04 15:37:14.037551+00	\N	\N	\N	\N	\N	\N	\N
fef4d6f8-f062-4f15-8c37-9f34897d1255	2715a5ba-2133-4fe9-af71-83c274e65cbc	4b516865-9bc6-45f7-b38f-5798c7f538b1	demo/2715a5ba-2133-4fe9-af71-83c274e65cbc/4b516865-9bc6-45f7-b38f-5798c7f538b1.webm	103.7	done	\N	2026-06-24 21:37:13.866395+00	2026-06-24 21:37:13.866395+00	2026-07-04 15:37:14.040815+00	\N	\N	\N	\N	\N	be4715f5-03c6-4d51-abe1-eb260900eb05	\N
a4541fb8-3afe-4450-a8db-0f3ceac92429	2715a5ba-2133-4fe9-af71-83c274e65cbc	802b412a-e6cd-4256-ab70-9adf3bb83a9e	demo/2715a5ba-2133-4fe9-af71-83c274e65cbc/802b412a-e6cd-4256-ab70-9adf3bb83a9e.webm	65	done	\N	2026-06-26 00:37:13.866395+00	2026-06-26 00:37:13.866395+00	2026-07-04 15:37:14.040815+00	\N	\N	\N	\N	\N	68a9b282-27f2-4c04-84cf-0e18e1b350d8	\N
5d986e15-5051-4878-a4a4-3cddbda19f39	2715a5ba-2133-4fe9-af71-83c274e65cbc	1176f594-6b2f-4b71-98c7-95736ab1d5c8	demo/2715a5ba-2133-4fe9-af71-83c274e65cbc/1176f594-6b2f-4b71-98c7-95736ab1d5c8.webm	77	done	\N	2026-06-30 21:37:13.866395+00	2026-06-30 21:37:13.866395+00	2026-07-04 15:37:14.040815+00	\N	\N	\N	\N	\N	\N	\N
663ebcec-4836-4b45-98af-f9fff4b7feef	8149a2f8-99af-4e89-a11e-89fb61297ef1	ae4c2325-a11c-4def-9408-71db92c21f26	demo/8149a2f8-99af-4e89-a11e-89fb61297ef1/ae4c2325-a11c-4def-9408-71db92c21f26.webm	80.8	done	\N	2026-06-25 02:37:13.866395+00	2026-06-25 02:37:13.866395+00	2026-07-04 15:37:14.04458+00	\N	\N	\N	\N	\N	\N	\N
0562f646-5808-4135-a753-4b75cee4c572	8149a2f8-99af-4e89-a11e-89fb61297ef1	1176f594-6b2f-4b71-98c7-95736ab1d5c8	demo/8149a2f8-99af-4e89-a11e-89fb61297ef1/1176f594-6b2f-4b71-98c7-95736ab1d5c8.webm	62.9	done	\N	2026-07-02 05:37:13.866395+00	2026-07-02 05:37:13.866395+00	2026-07-04 15:37:14.04458+00	\N	\N	\N	\N	\N	\N	\N
d1a855a9-40e8-41b7-82ee-54d09533864c	8149a2f8-99af-4e89-a11e-89fb61297ef1	802b412a-e6cd-4256-ab70-9adf3bb83a9e	demo/8149a2f8-99af-4e89-a11e-89fb61297ef1/802b412a-e6cd-4256-ab70-9adf3bb83a9e.webm	50.2	done	\N	2026-07-03 05:37:13.866395+00	2026-07-03 05:37:13.866395+00	2026-07-04 15:37:14.04458+00	\N	\N	\N	\N	\N	5392df78-31d4-4af7-af32-ec74553eb299	\N
e5994e27-be8a-4845-ab4f-2b5a572eb3af	8149a2f8-99af-4e89-a11e-89fb61297ef1	4b516865-9bc6-45f7-b38f-5798c7f538b1	demo/8149a2f8-99af-4e89-a11e-89fb61297ef1/4b516865-9bc6-45f7-b38f-5798c7f538b1.webm	63.1	done	\N	2026-06-26 01:37:13.866395+00	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:14.04458+00	\N	\N	\N	\N	\N	b59e946e-5966-4a64-b9f2-205a6cae6328	\N
93304d73-fbcc-42bc-8307-e5503b13b3f7	85a2e644-0cee-439c-88fb-590ea4128006	ae4c2325-a11c-4def-9408-71db92c21f26	demo/85a2e644-0cee-439c-88fb-590ea4128006/ae4c2325-a11c-4def-9408-71db92c21f26.webm	32.3	done	\N	2026-06-27 12:37:13.866395+00	2026-06-27 12:37:13.866395+00	2026-07-04 15:37:14.049113+00	\N	\N	\N	\N	\N	\N	\N
bf818566-9785-4f3f-a8d9-07d8e36f5ce5	85a2e644-0cee-439c-88fb-590ea4128006	802b412a-e6cd-4256-ab70-9adf3bb83a9e	demo/85a2e644-0cee-439c-88fb-590ea4128006/802b412a-e6cd-4256-ab70-9adf3bb83a9e.webm	48	done	\N	2026-06-28 13:37:13.866395+00	2026-06-28 13:37:13.866395+00	2026-07-04 15:37:14.049113+00	\N	\N	\N	\N	\N	195ae539-5dfc-45bc-b0b2-0a519ccbfcf7	\N
42920bf0-86de-4946-955d-4ebf2c021e6d	85a2e644-0cee-439c-88fb-590ea4128006	1176f594-6b2f-4b71-98c7-95736ab1d5c8	demo/85a2e644-0cee-439c-88fb-590ea4128006/1176f594-6b2f-4b71-98c7-95736ab1d5c8.webm	86.4	done	\N	2026-06-29 23:37:13.866395+00	2026-06-29 23:37:13.866395+00	2026-07-04 15:37:14.049113+00	\N	\N	\N	\N	\N	\N	\N
6fe0ce58-4e1e-43f7-aa39-7d5620976a3f	85a2e644-0cee-439c-88fb-590ea4128006	618daf8d-9b50-410e-9d6f-95034e3291c5	demo/85a2e644-0cee-439c-88fb-590ea4128006/618daf8d-9b50-410e-9d6f-95034e3291c5.webm	70.7	done	\N	2026-06-30 20:37:13.866395+00	2026-06-30 20:37:13.866395+00	2026-07-04 15:37:14.049113+00	\N	\N	\N	\N	\N	\N	\N
6bba967e-e0e6-4127-bd11-ece5eb6e1e24	2bd4f4d6-8843-430b-bf36-834571f75b2c	\N	shadow/8ec4f982f5cb497aa3a6a85190967b18.webm	3.612	done	\N	2026-07-09 04:47:11.871486+00	2026-07-09 04:46:55.73237+00	2026-07-09 04:46:58.217536+00	\N	\N	\N	\N	Привет! Меня зовут Анна.	\N	\N
11ff5003-d2b8-4b46-8252-0641f27e061c	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	4026168a-4225-4b1d-9d24-02600e37775e	answers/cdd91dc72a994fa6ad3f1597667fb758.webm	7.761	done	429 RESOURCE_EXHAUSTED. {'error': {'code': 429, 'message': 'You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-api/docs/rate-limits. To monitor your current usage, head to: https://ai.dev/rate-limit. \\n* Quota exceeded for metric: generativelanguage.googleapis.com/generate_content_free_tier_requests, limit: 500, model: gemini-3.1-flash-lite\\nPlease retry in 39.514679165s.', 'status': 'RESOURCE_EXHAUSTED', 'details': [{'@type': 'type.googleapis.com/google.rpc.Help', 'links': [{'description': 'Learn more about Gemini API quotas', 'url': 'https://ai.google.dev/gemini-api/docs/rate-limits'}]}, {'@type': 'type.googleapis.com/google.rpc.QuotaFailure', 'violations': [{'quotaMetric': 'generativelanguage.googleapis.com/generate_content_free_tier_requests', 'quotaId': 'GenerateRequestsPerDayPerProjectPerModel-FreeTier', 'quotaDimensions': {'location': 'global', 'model': 'gemini-3.1-flash-lite'}, '	2026-07-09 05:39:09.419711+00	2026-07-09 05:21:57.080909+00	2026-07-09 05:38:32.70167+00	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: topic_images; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.topic_images (id, topic_id, image_key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.topics (id, teacher_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transcripts; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.transcripts (id, submission_id, text, language, word_timestamps, stt_model, created_at, updated_at, pronunciation) FROM stdin;
7c103850-c575-4436-8f3d-e40e7d6fb9d5	0edd8fb7-d6fd-4f96-9d3a-cae4cfe1d7da	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	\N
d384a9a7-b014-4f05-9312-3ab2b9b46672	54d45ccc-ad23-41c1-9171-22fb4b9e785e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	\N
187ac82e-ffff-44c9-938c-0540092010f2	3f43c22e-cbdb-44bb-a828-5f553b3eedb2	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	\N
f5e0b408-6080-428e-ad93-3c71df0a38ab	4d836253-0a6a-40df-b086-3e6318281c44	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	\N
1ab95413-2cdc-42da-8f50-881025b8cad1	e42cb28b-7ffc-4a3f-9610-2e3e73f428e4	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.905432+00	2026-07-04 15:37:13.905432+00	\N
51a76ab0-f714-4fe8-8bc0-786cb3035bb7	71a0dd5e-fca5-4458-a856-4e68777b43de	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	\N
af29b948-53fa-49cd-94a1-5bd0335c4f2d	f756aacb-5f37-473e-a451-d374bc40ab16	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	\N
f876d6d7-26ce-4514-8215-fda098a45d9b	7ffc76f7-0ac4-43e7-9fea-de41ff0f5bd2	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	\N
52c32b98-21d5-4dce-b4a5-ed922816cb3b	495f9102-c7d9-42b9-b358-aa3884aa4b25	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	\N
7374ec93-6afe-417b-aae9-74a49312dc97	98bd9179-d490-416a-97bc-1a7390026fde	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.914893+00	2026-07-04 15:37:13.914893+00	\N
f99de55f-26d7-4990-afdd-e99426273bdf	f90a1068-a5e3-49fb-ad2f-0df9e0b11940	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	\N
89b4a014-9b3e-437d-ad8c-bcc2af0e58fe	d5bcba45-e4cf-4c88-b53f-87e80a3ccebd	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	\N
9bb707e8-8ad0-4bd1-b811-f5dd95add1b4	9263acef-c8cd-4602-a47d-58f87d55cce5	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	\N
2d003bb9-2187-4649-9b4c-a472d2dee43a	6cfca392-aba9-410b-9a34-a3d45ea95b51	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	\N
85c4c46f-b6c1-4994-aeea-2fa34aebef08	5225ae61-40e1-4a32-815f-4d2641f7d065	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.920389+00	2026-07-04 15:37:13.920389+00	\N
cf8d915c-14b7-49b4-b875-45851e52ec27	9ca9d239-bd66-40de-8ee0-5ef980545bfe	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	\N
07bcc181-895d-4925-b943-45402dfb5150	83d77585-5719-44b0-ac59-f6977e014e6c	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	\N
cd9bbeda-4044-4058-a022-0f08b9a04739	ce21e2a4-781d-40b6-af08-293ec290d2ef	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.925356+00	2026-07-04 15:37:13.925356+00	\N
c7b5be4d-85af-4044-9e5b-0a2187241b17	2b9a4f94-cdb6-432e-bc8b-24e1994aea14	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	\N
7981be7a-1907-4eeb-897a-d651f2f6e777	0bb4e935-9c4b-4b45-af31-58f4a31641b2	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	\N
dd1dccc0-833b-4636-800a-bf9a2939534f	d8612cb3-1555-4dbc-841b-105785ec214d	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	\N
dbd0f0a4-ef1d-4459-9430-297d3a4ecd36	94dca90e-6adc-4e44-ab6d-7266c1b4129d	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	\N
35c03839-5f4e-49aa-9ad0-5a3d69a9a1e4	cea5aa89-43dd-4fbf-bdf6-668d3d3fbcdb	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.928285+00	2026-07-04 15:37:13.928285+00	\N
51eb6d67-24c6-4f39-aff0-a002377ab589	e83bfa36-844d-4100-a358-0794d8e1b38f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	\N
9cb8483f-c567-48cf-84ad-519ceb00d442	5e3289f7-48bf-47d8-b6a1-73cf4a201935	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	\N
c02cba2e-9ba5-4ed2-8efe-86ff706ddcd4	7e1721fd-8c95-44ff-b0c5-3b2d9b8877ab	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.944695+00	2026-07-04 15:37:13.944695+00	\N
4dc8d1ea-5a38-45e6-a472-c930cc87bf11	16c1a37b-293b-4906-a5f6-98a76614d0b4	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	\N
b7c776c6-7741-4618-805f-1243090b2699	9ffd376c-ae9f-4d8f-85c8-dc4a9bd4d2c9	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	\N
bc4fca98-335c-4a39-9874-a49723e2c5f5	8f40f70d-462d-4721-9ac9-a48651706869	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	\N
dd7722d2-cf51-48b1-8d0a-568d3cf8d74a	a0c23ea8-77bc-4eff-902c-158bf503b9ff	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	\N
56491ff5-e515-45c0-9fb4-0d9f96cc521d	91f2163f-8848-4700-bb02-cda2410227ec	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.948024+00	2026-07-04 15:37:13.948024+00	\N
9856b7e6-1195-40df-8d51-e2ea68c01a68	9884e60a-3824-4c5b-87ff-21e3392bd679	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	\N
f2575b62-bd53-4f24-b453-bafdd6423384	216f4459-017f-44f8-a396-c347c10aeb7e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	\N
d7ade172-dc65-477f-890d-51f505569c7a	1764a08c-5437-4934-8c36-4a52fe8be50f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.953035+00	2026-07-04 15:37:13.953035+00	\N
db47121d-0180-4a70-8aac-bced99c78b6e	f69940b2-96fa-4e98-bfbb-014af377cf43	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	\N
ba8c2549-05fd-43bf-aa2f-9d44904d985e	4f1a70dd-699f-47f9-9249-4d9159ff1779	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	\N
fd4f3f7d-2566-4238-9832-0fbf66e40fa9	6ced6c01-eed9-427f-a03f-15aa27cb6b28	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.956359+00	2026-07-04 15:37:13.956359+00	\N
c2f8584c-a1da-48d7-84ee-f39eb717fbdc	66a1d5b4-7907-4b3a-88ad-fb78cea62395	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	\N
ae9724c1-d400-450f-9c68-22d7be403d58	95b44407-9a6e-4115-b18e-3dcaf8fd54c3	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	\N
6a0f711b-664a-4eb2-85a4-0a1f30dc5b23	5f4ebf45-1bfe-475c-a858-6ac668d5171f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	\N
ec7b8812-9460-40c0-97ce-18cee476ade6	d73fb91d-6a83-4158-9356-9a49ef6447d2	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.95938+00	2026-07-04 15:37:13.95938+00	\N
5f050932-2948-493c-a30b-f6cc160b1930	45673d97-c4d0-4680-9bc5-665e72a7995e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	\N
b8eca554-a736-4126-90ee-ddad6beca446	f61fde7d-326d-4462-a5ff-ef66df54d9e7	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	\N
aa84ec4b-7da6-4e85-9e2d-78a9d45df18a	09a5bf13-99a0-42e5-97dd-1012a92b88f6	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	\N
917cdb6d-da47-44e8-b1ec-589d3d86828a	6e76bbb7-54ee-4662-97c6-aaabec0462b5	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.974962+00	2026-07-04 15:37:13.974962+00	\N
c8086148-cf71-42de-aa78-7edb34c0fd34	fede438b-b7c4-4ae1-a583-e09bf7214c41	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	\N
49e0f65d-8bb4-4c00-9ae5-e77f35430037	6cea0ca9-3583-429e-8102-a5a4fd364193	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	\N
a755a700-86a4-45de-91e5-1bc8760ee04e	768cfd45-f415-46cb-86f0-c1e3f4d96671	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	\N
2d1b9ee3-8337-420a-95b3-f6abbce4c47d	f94ebff4-9fb7-4883-b15a-fb25e3248cb9	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.978905+00	2026-07-04 15:37:13.978905+00	\N
43910ac6-90ac-45c8-92bc-eba712feeb27	3f0f9ced-e914-42c7-af90-cbab87e325de	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	\N
f902a44f-1f31-4b54-91b9-c4ec22dac4c2	8c667cad-e6d6-4470-8af7-04e82391ae6e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	\N
0b967ac9-3acd-4ab8-87a8-7ad940b27c1e	b9238b70-4c37-438d-a88a-aa3ec56c9b71	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.982684+00	2026-07-04 15:37:13.982684+00	\N
a6b2d012-c67b-4768-a92a-d232c263d215	31a5ec23-c1e5-4c8c-a4cc-39d17b9d98ab	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	\N
971f5232-2d11-491a-b890-bf6a041a600a	4e5e81be-363f-481d-80b5-2430fff7a5ca	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	\N
c58f380b-8af8-4f05-a7c7-13dd331cb152	8e4bb48a-9e44-4c18-ab58-7fe2359df794	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.986006+00	2026-07-04 15:37:13.986006+00	\N
7601ce6d-b317-4c9c-b1c2-17f4838c5fb5	aa72dd02-86f7-4c19-85cb-7b5cae529831	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	\N
9e53929b-d4ea-42c7-8811-2da3e7b28897	2f47ca19-057d-4980-b3df-1c319a8a2dab	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	\N
19a70ca6-7b66-4702-a84c-3525c9f2445f	40eb9350-7635-431e-ae7c-aa753f1e0e9a	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:13.989101+00	2026-07-04 15:37:13.989101+00	\N
b41b6400-4791-4d0b-bd51-22c3b52f2df3	b23fc5ca-10ac-471e-a2cd-c51adabc7658	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	\N
d627bd2a-e857-4e59-8a22-869ab5ea6466	66d09a8f-023b-40c5-9221-59d12805cc2c	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	\N
0970a3a5-090d-494c-b30b-46171e4240e3	4bbe2fbb-ce58-4e74-8e36-ffde513b5ad9	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	\N
74307cf9-edf6-41bb-933f-1dc809b62424	fb4a92cb-afa8-4657-be68-08d63ac9dd2e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	\N
89e7a2c3-e500-4a1d-b66e-c203a068cc36	0b5d5bcf-d14f-4edf-9c29-8b00533bb9de	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.003592+00	2026-07-04 15:37:14.003592+00	\N
3f36f947-60a6-4c57-ba35-eea6d435720f	09952ee0-3b05-49ef-8db4-519bd3a4b743	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	\N
c6f2f559-25df-4e02-b782-f1a110dbcb2b	9018bd1e-547c-4a3f-8199-b78b8f4404e1	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	\N
f947e6cd-4727-482e-ac96-0ad1a76b9f82	48247057-f810-48f7-8cc4-0ac3cff4b84a	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.008312+00	2026-07-04 15:37:14.008312+00	\N
b284b4d8-a449-4f1b-8149-79fc3c3b3d0e	f36ea940-be4f-42e5-846e-419f87f21c02	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	\N
45cc0950-fbfc-4d7c-882c-d8d3a60e4c3d	e10f3719-3b8f-495c-b438-b3c8859e890b	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	\N
9a98d905-102b-4603-ba03-0ff19e4b4a45	419ec27e-11e0-478f-b62d-791043fd431e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.011634+00	2026-07-04 15:37:14.011634+00	\N
518010ec-9412-4f67-b762-0ad1eaa15f7f	7b39b83e-43cb-440f-88df-b77b00d99a6f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	\N
e5f29843-8276-4063-af89-7606f9b9ea6c	755eb452-2de0-4151-bff3-f279c077aea0	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	\N
c302ea17-fbb5-460d-b694-3b223969f312	ed953bc7-0e32-4f29-951a-790dcae2b4a1	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.014855+00	2026-07-04 15:37:14.014855+00	\N
01c3c1d4-7f63-4ad7-84ce-d4502243c132	8b6c5e05-3c6e-40fb-a086-4401c4390637	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	\N
3923ed6d-92f1-4980-8f30-d04b756d097b	3083ed90-1c08-43bb-8676-ba214c62916e	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	\N
ecb929e2-5139-4a44-be58-ae1d4635380f	a690611f-b1e0-476c-95dd-914648dd1d12	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	\N
f687d8fb-0056-45ac-b4b7-6cfdf8c660fa	e031cbea-392d-4bb6-8053-7f178866c88c	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.018145+00	2026-07-04 15:37:14.018145+00	\N
ed530c88-b0e6-4507-a96f-4c3bc95ce0ca	d62885ce-cc8e-4f98-9606-438cd9443325	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	\N
504f6175-9541-4474-8237-8cac4bbfd482	8dd27d45-c888-436a-b978-4695143b170c	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	\N
79fb16ec-2bca-4546-a705-f28cd5bad29b	2b4efca5-c485-42d5-9702-46c4bec8c069	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.034497+00	2026-07-04 15:37:14.034497+00	\N
10111063-966f-47f1-9e77-635d60430145	c16922f7-8eae-4794-8003-01b25d98ce4f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	\N
8c5145b1-85eb-49b0-b417-0581d3cae58f	cf1d1cef-9c87-4628-8948-2d61eceeea95	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	\N
25bb2003-d6a8-4bbd-8d32-02eeaeeedba6	c72a58aa-bd06-474c-827c-d79c305d72f5	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.037551+00	2026-07-04 15:37:14.037551+00	\N
e131bf93-ce4d-4583-89a8-ac07531d4371	fef4d6f8-f062-4f15-8c37-9f34897d1255	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	\N
3ce3e19b-f1a6-4374-abc0-7d96f6fd39d7	a4541fb8-3afe-4450-a8db-0f3ceac92429	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	\N
add5a776-1815-4cac-9e86-77ea15f41721	5d986e15-5051-4878-a4a4-3cddbda19f39	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.040815+00	2026-07-04 15:37:14.040815+00	\N
85afa8ac-29ff-460d-b985-8d823ebfbcf2	663ebcec-4836-4b45-98af-f9fff4b7feef	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	\N
e1f3bea2-0e96-4400-afb7-94fb8657925f	0562f646-5808-4135-a753-4b75cee4c572	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	\N
c9bf497d-79b3-4d23-8705-0878c5de336f	d1a855a9-40e8-41b7-82ee-54d09533864c	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	\N
6cb03a37-0e91-4783-9dfa-0368af0df6af	e5994e27-be8a-4845-ab4f-2b5a572eb3af	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.04458+00	2026-07-04 15:37:14.04458+00	\N
e7a6493f-4fe6-4253-a20e-c5e2632fe5a7	93304d73-fbcc-42bc-8307-e5503b13b3f7	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	\N
f84fda6d-93e4-479b-94ee-8c08bab6b6dd	bf818566-9785-4f3f-a8d9-07d8e36f5ce5	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	\N
82db1da0-31ef-410c-8f18-9c76f19b6b6c	42920bf0-86de-4946-955d-4ebf2c021e6d	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	\N
19981a92-c1b4-4173-b88d-3c0656c116f2	6fe0ce58-4e1e-43f7-aa39-7d5620976a3f	Это демонстрационный ответ, добавленный для примера статистики.	ru	\N	demo	2026-07-04 15:37:14.049113+00	2026-07-04 15:37:14.049113+00	\N
b42202e8-0156-499d-b2fe-a9d1579f64b7	6bba967e-e0e6-4127-bd11-ece5eb6e1e24	привет всем меня зовут анна	ru-RU	[{"end": 2.18, "word": "привет", "start": 1.71, "accuracy": 82.0, "phonemes": null, "error_type": "None"}, {"end": 2.39, "word": "всем", "start": 2.19, "accuracy": 62.0, "phonemes": null, "error_type": "None"}, {"end": 2.58, "word": "меня", "start": 2.4, "accuracy": 54.0, "phonemes": null, "error_type": "Mispronunciation"}, {"end": 2.88, "word": "зовут", "start": 2.59, "accuracy": 53.0, "phonemes": null, "error_type": "Mispronunciation"}, {"end": 3.3, "word": "анна", "start": 2.89, "accuracy": 54.0, "phonemes": null, "error_type": "Mispronunciation"}]	azure-speech-pa	2026-07-09 04:46:55.791999+00	2026-07-09 04:46:55.791999+00	{"fluency": 43.0, "prosody": null, "accuracy": 61.0, "completeness": 100.0, "pronunciation": 50.2, "reference_match": {"on_topic": true, "similarity": 0.889, "completeness": 100.0, "spoken_words": 5, "matched_words": 4, "reference_words": 4}}
cc258ddb-dcfb-4657-ab0f-df0a930c89c7	11ff5003-d2b8-4b46-8252-0641f27e061c	расскажите что вы любите если какой нибудь проект почитайте	ru-RU	[{"end": 2.46, "word": "расскажите", "start": 1.48, "accuracy": 92.0, "phonemes": null, "error_type": "None"}, {"end": 2.67, "word": "что", "start": 2.47, "accuracy": 85.0, "phonemes": null, "error_type": "None"}, {"end": 2.81, "word": "вы", "start": 2.68, "accuracy": 60.0, "phonemes": null, "error_type": "None"}, {"end": 3.4, "word": "любите", "start": 2.82, "accuracy": 89.0, "phonemes": null, "error_type": "None"}, {"end": 3.73, "word": "если", "start": 3.41, "accuracy": 42.0, "phonemes": null, "error_type": "Mispronunciation"}, {"end": 4.39, "word": "какой", "start": 3.74, "accuracy": 52.0, "phonemes": null, "error_type": "Mispronunciation"}, {"end": 5.04, "word": "нибудь", "start": 4.4, "accuracy": 91.0, "phonemes": null, "error_type": "None"}, {"end": 5.75, "word": "проект", "start": 5.08, "accuracy": 48.0, "phonemes": null, "error_type": "Mispronunciation"}, {"end": 6.72, "word": "почитайте", "start": 5.76, "accuracy": 94.0, "phonemes": null, "error_type": "None"}]	azure-speech-pa	2026-07-09 05:21:57.105043+00	2026-07-09 05:21:57.105043+00	{"fluency": 68.0, "prosody": null, "accuracy": 73.0, "completeness": 100.0, "pronunciation": 70.0}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.users (id, email, password_hash, full_name, role, is_active, created_at, updated_at, preferred_language, is_premium, google_sub, xp, daily_goal, streak_freezes, current_streak, longest_streak, last_practice_date, phone, age, region, district, telegram, avatar_key) FROM stdin;
8fc1d1bd-33d4-45e2-b6e9-8f26c3e9363c	teacher1@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Ойбек Каримов	teacher	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:37:13.880419+00	uz	f	\N	0	1	0	0	0	\N	+998901112201	\N	\N	\N	@oybek_teacher	\N
904bccd8-950a-45ed-afd2-e56a40a99a6b	admin@govorim.uz	$2b$12$FisvjmhcK7.mV7WQS5zhhurFCWlvjjld2/fRLT48bl02/tTdiXofi	Admin	admin	t	2026-07-04 14:44:52.219949+00	2026-07-09 04:36:36.696304+00	uz	f	\N	0	1	0	0	0	\N	\N	\N	\N	\N	\N	\N
98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	student2@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Иван Петров	student	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:37:13.914893+00	uz	f	\N	730	1	0	9	9	2026-07-04	+998991200001	\N	\N	\N	\N	\N
9000ce1c-4db1-499a-a465-34edcabe7f1b	student3@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Мария Сидорова	student	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:37:13.920389+00	uz	f	\N	694	1	0	9	9	2026-07-04	+998991200002	\N	\N	\N	\N	\N
b578f40c-4b35-40c3-b1d4-e8520a8ba23b	student4@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Дмитрий Смирнов	student	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:37:13.925356+00	uz	f	\N	446	1	0	4	4	2026-07-04	+998991200003	\N	\N	\N	\N	\N
bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	student5@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Елена Кузнецова	student	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:37:13.928285+00	uz	f	\N	704	1	0	8	8	2026-07-02	+998991200004	\N	\N	\N	\N	\N
395a1ec7-2554-4a7c-b93f-e98c51428b82	teacher2@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Нигора Юсупова	teacher	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.932922+00	uz	f	\N	0	1	0	0	0	\N	+998901112202	\N	\N	\N	@nigora_teach	\N
6832d92c-b0ef-490d-805c-98cbd726f198	student6@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Алексей Попов	student	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.944695+00	uz	t	\N	444	1	0	9	9	2026-06-28	+998991200005	\N	\N	\N	\N	\N
a8c7fcc3-947f-421d-ad5a-a2d6cd448977	student7@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Ольга Васильева	student	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.948024+00	uz	f	\N	682	1	0	2	2	2026-07-03	+998991200006	\N	\N	\N	\N	\N
662b71e8-b41e-4198-a07c-9fdb8288e651	student8@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Сергей Новиков	student	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.953035+00	uz	f	\N	454	1	0	6	6	2026-07-03	+998991200007	\N	\N	\N	\N	\N
99bff3a0-8237-4afd-bd58-937faf6cbaae	student9@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Наталья Морозова	student	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.956359+00	uz	f	\N	392	1	0	1	1	2026-07-04	+998991200008	\N	\N	\N	\N	\N
b584e81c-08dd-4f1f-b181-6e02de1214b0	student10@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Павел Волков	student	t	2026-07-04 15:37:13.932922+00	2026-07-04 15:37:13.95938+00	uz	f	\N	578	1	0	2	2	2026-07-02	+998991200009	\N	\N	\N	\N	\N
656f43bd-8532-481b-bc31-aed8cb9abaad	teacher3@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Жасур Рахимов	teacher	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.963525+00	uz	f	\N	0	1	0	0	0	\N	+998901112203	\N	\N	\N	@jasur_ru	\N
b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	student11@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Татьяна Соколова	student	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.974962+00	uz	t	\N	612	1	0	9	9	2026-07-04	+998991200010	\N	\N	\N	\N	\N
6f394335-b63b-4c72-b929-78733facb505	student12@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Андрей Лебедев	student	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.978905+00	uz	f	\N	596	1	0	4	4	2026-06-29	+998991200011	\N	\N	\N	\N	\N
9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	student13@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Ирина Козлова	student	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.982684+00	uz	f	\N	420	1	0	8	8	2026-06-28	+998991200012	\N	\N	\N	\N	\N
1f8f0810-c92e-48f5-9bc7-eda00173e390	student14@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Никита Егоров	student	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.986006+00	uz	f	\N	432	1	0	4	4	2026-07-01	+998991200013	\N	\N	\N	\N	\N
51cfb12f-6865-4891-8342-aec015a5f60c	student15@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Юлия Павлова	student	t	2026-07-04 15:37:13.963525+00	2026-07-04 15:37:13.989101+00	uz	f	\N	452	1	0	7	7	2026-06-26	+998991200014	\N	\N	\N	\N	\N
f604d00d-599b-434e-8535-d069cccac127	teacher4@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Малика Тошева	teacher	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:13.992252+00	uz	f	\N	0	1	0	0	0	\N	+998901112204	\N	\N	\N	@malika_ru	\N
67e3cbb6-67b6-4750-98bd-c43809d9e5ff	student16@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Артём Орлов	student	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:14.003592+00	uz	t	\N	722	1	0	2	2	2026-07-03	+998991200015	\N	\N	\N	\N	\N
13b13315-eb4e-4da6-b645-e558bf78f6db	student17@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Дарья Макарова	student	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:14.008312+00	uz	f	\N	436	1	0	8	8	2026-07-04	+998991200016	\N	\N	\N	\N	\N
182470a9-678c-4231-bbbf-41d427773497	student18@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Максим Никитин	student	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:14.011634+00	uz	f	\N	468	1	0	8	8	2026-06-27	+998991200017	\N	\N	\N	\N	\N
8f73affc-cb6c-4b19-92fc-2337385eb851	student19@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	София Захарова	student	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:14.014855+00	uz	f	\N	432	1	0	9	9	2026-07-01	+998991200018	\N	\N	\N	\N	\N
12b3b088-bdf0-4379-b2a7-aeae73280ea6	student20@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Роман Фёдоров	student	t	2026-07-04 15:37:13.992252+00	2026-07-04 15:37:14.018145+00	uz	f	\N	560	1	0	6	6	2026-07-01	+998991200019	\N	\N	\N	\N	\N
57917a22-78cf-497e-94bb-a4813c056f6f	teacher5@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Бекзод Алиев	teacher	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.022161+00	uz	f	\N	0	1	0	0	0	\N	+998901112205	\N	\N	\N	@bekzod_teach	\N
9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	student21@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Виктория Белова	student	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.034497+00	uz	t	\N	434	1	0	2	2	2026-07-03	+998991200020	\N	\N	\N	\N	\N
86df832e-096f-4174-b022-a932fedefca0	student22@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Кирилл Тарасов	student	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.037551+00	uz	f	\N	434	1	0	3	3	2026-07-04	+998991200021	\N	\N	\N	\N	\N
2715a5ba-2133-4fe9-af71-83c274e65cbc	student23@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Полина Романова	student	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.040815+00	uz	f	\N	450	1	0	3	3	2026-06-30	+998991200022	\N	\N	\N	\N	\N
607e5ea6-022e-4fee-b012-78a186ca42c0	student1@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Анна Иванова	student	t	2026-07-04 15:37:13.880419+00	2026-07-04 15:50:58.752111+00	uz	t	\N	734	1	0	4	4	2026-07-01	+998991200000	22	Toshkent shahri	Bektemir	\N	avatars/607e5ea6-022e-4fee-b012-78a186ca42c0/12696817eabe45df86d3cbf91340f5cc.jpeg
8149a2f8-99af-4e89-a11e-89fb61297ef1	student24@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Глеб Медведев	student	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.04458+00	uz	f	\N	584	1	0	4	4	2026-07-03	+998991200023	\N	\N	\N	\N	\N
85a2e644-0cee-439c-88fb-590ea4128006	student25@demo.uz	$2b$12$h3v84o.P2K4avNFTbstiQ.gHXCgSAbeBSE0i0vN3qPrxx3ddT9dvS	Алиса Ковалёва	student	t	2026-07-04 15:37:14.022161+00	2026-07-04 15:37:14.049113+00	uz	f	\N	614	1	0	9	9	2026-06-30	+998991200024	\N	\N	\N	\N	\N
2bd4f4d6-8843-430b-bf36-834571f75b2c	admin@test.uz	$2b$12$NaK36.dJRJxnBo4i8OLp/eJy5GXroqwhRa3s/RVbH49HJvNaAjA9O	Admin	admin	t	2026-07-09 04:45:08.996033+00	2026-07-09 04:45:08.996033+00	uz	f	\N	0	1	0	0	0	\N	\N	\N	\N	\N	\N	\N
cd39ff39-1dee-4ed2-8726-9ad07449fb05	teacher@test.uz	$2b$12$NaK36.dJRJxnBo4i8OLp/eJy5GXroqwhRa3s/RVbH49HJvNaAjA9O	Teacher	teacher	t	2026-07-09 04:45:08.996033+00	2026-07-09 04:45:08.996033+00	uz	f	\N	0	1	0	0	0	\N	\N	\N	\N	\N	\N	\N
f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	student@test.uz	$2b$12$NaK36.dJRJxnBo4i8OLp/eJy5GXroqwhRa3s/RVbH49HJvNaAjA9O	Student	student	t	2026-07-09 04:45:08.996033+00	2026-07-09 05:25:45.322233+00	uz	f	\N	0	1	0	1	1	2026-07-09	+998123456789	23	Toshkent shahri	Chilonzor	\N	\N
\.


--
-- Data for Name: xp_events; Type: TABLE DATA; Schema: public; Owner: russpeak
--

COPY public.xp_events (id, student_id, submission_id, amount, reason, created_at, updated_at) FROM stdin;
e1f67035-9496-4581-895d-3ab41106c8bf	607e5ea6-022e-4fee-b012-78a186ca42c0	0edd8fb7-d6fd-4f96-9d3a-cae4cfe1d7da	148	submission	2026-07-01 11:37:13.866395+00	2026-07-04 15:37:13.905432+00
3a2c0bd6-e982-4195-8e05-73e115a1ae5e	607e5ea6-022e-4fee-b012-78a186ca42c0	54d45ccc-ad23-41c1-9171-22fb4b9e785e	134	submission	2026-07-01 08:37:13.866395+00	2026-07-04 15:37:13.905432+00
244c58e4-31b1-44c9-a112-7acec1d4e6fa	607e5ea6-022e-4fee-b012-78a186ca42c0	3f43c22e-cbdb-44bb-a828-5f553b3eedb2	144	submission	2026-06-25 07:37:13.866395+00	2026-07-04 15:37:13.905432+00
4ad446d4-9966-4c6b-8cc7-489388856bb9	607e5ea6-022e-4fee-b012-78a186ca42c0	4d836253-0a6a-40df-b086-3e6318281c44	154	submission	2026-06-29 12:37:13.866395+00	2026-07-04 15:37:13.905432+00
b2b88922-179c-452f-85c3-5883caf13008	607e5ea6-022e-4fee-b012-78a186ca42c0	e42cb28b-7ffc-4a3f-9610-2e3e73f428e4	154	submission	2026-06-26 12:37:13.866395+00	2026-07-04 15:37:13.905432+00
f458ec04-b55a-49d0-a84d-397c747fd14d	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	71a0dd5e-fca5-4458-a856-4e68777b43de	142	submission	2026-07-03 08:37:13.866395+00	2026-07-04 15:37:13.914893+00
616cb42c-4620-46c6-aae8-591616bccbd4	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	f756aacb-5f37-473e-a451-d374bc40ab16	144	submission	2026-06-24 07:37:13.866395+00	2026-07-04 15:37:13.914893+00
d3b4fc9a-ecbb-44cd-a6de-6116b07fbfce	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	7ffc76f7-0ac4-43e7-9fea-de41ff0f5bd2	148	submission	2026-06-27 03:37:13.866395+00	2026-07-04 15:37:13.914893+00
1a688d38-acd1-4b42-b22b-81c48b841a68	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	495f9102-c7d9-42b9-b358-aa3884aa4b25	150	submission	2026-07-04 08:37:13.866395+00	2026-07-04 15:37:13.914893+00
ba4532b0-079c-438f-891c-76f9d44d429d	98e7b29c-43bd-4e5d-b56a-c3cd680d16e4	98bd9179-d490-416a-97bc-1a7390026fde	146	submission	2026-06-29 09:37:13.866395+00	2026-07-04 15:37:13.914893+00
4e1beb88-23c5-4454-83bf-483fe8bdfe0a	9000ce1c-4db1-499a-a465-34edcabe7f1b	f90a1068-a5e3-49fb-ad2f-0df9e0b11940	124	submission	2026-07-01 11:37:13.866395+00	2026-07-04 15:37:13.920389+00
c019d325-c161-4c31-a0c5-5a6ca9ade566	9000ce1c-4db1-499a-a465-34edcabe7f1b	d5bcba45-e4cf-4c88-b53f-87e80a3ccebd	164	submission	2026-06-27 20:37:13.866395+00	2026-07-04 15:37:13.920389+00
ff72b016-f614-4df8-b49e-c24f1b7d1c47	9000ce1c-4db1-499a-a465-34edcabe7f1b	9263acef-c8cd-4602-a47d-58f87d55cce5	136	submission	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.920389+00
1bbeaae9-0e63-41cc-a15c-a789e8343dab	9000ce1c-4db1-499a-a465-34edcabe7f1b	6cfca392-aba9-410b-9a34-a3d45ea95b51	140	submission	2026-06-27 15:37:13.866395+00	2026-07-04 15:37:13.920389+00
77e5960e-df39-4b0c-a6c0-732093d3acc0	9000ce1c-4db1-499a-a465-34edcabe7f1b	5225ae61-40e1-4a32-815f-4d2641f7d065	130	submission	2026-06-24 06:37:13.866395+00	2026-07-04 15:37:13.920389+00
e3ca4bdd-a9f0-4975-b042-08b3567313bd	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	9ca9d239-bd66-40de-8ee0-5ef980545bfe	146	submission	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.925356+00
e90de1c3-7297-47cc-9d4b-63a9ba4cc49a	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	83d77585-5719-44b0-ac59-f6977e014e6c	154	submission	2026-07-03 13:37:13.866395+00	2026-07-04 15:37:13.925356+00
0bb7ad60-2371-403e-9cab-f73481091787	b578f40c-4b35-40c3-b1d4-e8520a8ba23b	ce21e2a4-781d-40b6-af08-293ec290d2ef	146	submission	2026-06-26 10:37:13.866395+00	2026-07-04 15:37:13.925356+00
30edc762-edeb-428a-be90-48d250d1c730	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	2b9a4f94-cdb6-432e-bc8b-24e1994aea14	132	submission	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:13.928285+00
69cde97e-3bed-45d2-ae73-9037b5b1fa1a	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	0bb4e935-9c4b-4b45-af31-58f4a31641b2	124	submission	2026-07-02 19:37:13.866395+00	2026-07-04 15:37:13.928285+00
fd8be650-8710-4652-9805-bb4a55e76226	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	d8612cb3-1555-4dbc-841b-105785ec214d	154	submission	2026-06-27 09:37:13.866395+00	2026-07-04 15:37:13.928285+00
79591304-1faf-4fbb-a072-4a0af88ceed7	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	94dca90e-6adc-4e44-ab6d-7266c1b4129d	152	submission	2026-06-28 09:37:13.866395+00	2026-07-04 15:37:13.928285+00
be6741a6-63c5-4333-ac93-ee2f5a1d0b95	bf2422bc-e4e1-4f1e-a8ca-ae3f0628ae85	cea5aa89-43dd-4fbf-bdf6-668d3d3fbcdb	142	submission	2026-06-23 19:37:13.866395+00	2026-07-04 15:37:13.928285+00
1e955d01-5562-4fb2-bbc3-31ea20cea41a	6832d92c-b0ef-490d-805c-98cbd726f198	e83bfa36-844d-4100-a358-0794d8e1b38f	142	submission	2026-06-27 08:37:13.866395+00	2026-07-04 15:37:13.944695+00
2e6f42de-6d54-43c4-b22e-e8f5587192b1	6832d92c-b0ef-490d-805c-98cbd726f198	5e3289f7-48bf-47d8-b6a1-73cf4a201935	154	submission	2026-06-26 15:37:13.866395+00	2026-07-04 15:37:13.944695+00
5f9c9f0d-b584-4d12-a896-7f14c95d4b88	6832d92c-b0ef-490d-805c-98cbd726f198	7e1721fd-8c95-44ff-b0c5-3b2d9b8877ab	148	submission	2026-06-28 14:37:13.866395+00	2026-07-04 15:37:13.944695+00
f0910cb8-ecc0-4063-80a3-39e9bfc8f194	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	16c1a37b-293b-4906-a5f6-98a76614d0b4	124	submission	2026-07-03 21:37:13.866395+00	2026-07-04 15:37:13.948024+00
7276445c-7502-4621-8c92-6072916853e5	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	9ffd376c-ae9f-4d8f-85c8-dc4a9bd4d2c9	136	submission	2026-06-26 10:37:13.866395+00	2026-07-04 15:37:13.948024+00
a2acda06-e609-4ea6-b54a-895a7cddd7be	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	8f40f70d-462d-4721-9ac9-a48651706869	130	submission	2026-06-28 12:37:13.866395+00	2026-07-04 15:37:13.948024+00
54555265-af6e-4db3-b639-c061f0ebb515	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	a0c23ea8-77bc-4eff-902c-158bf503b9ff	136	submission	2026-06-24 23:37:13.866395+00	2026-07-04 15:37:13.948024+00
197d0b7b-daa8-45a6-babf-c64bfb448ae4	a8c7fcc3-947f-421d-ad5a-a2d6cd448977	91f2163f-8848-4700-bb02-cda2410227ec	156	submission	2026-06-24 06:37:13.866395+00	2026-07-04 15:37:13.948024+00
17d932c6-d6c6-401e-8bba-59497770bc3c	662b71e8-b41e-4198-a07c-9fdb8288e651	9884e60a-3824-4c5b-87ff-21e3392bd679	152	submission	2026-06-30 11:37:13.866395+00	2026-07-04 15:37:13.953035+00
540647e0-aa6a-48f6-b03f-f9957fa46b99	662b71e8-b41e-4198-a07c-9fdb8288e651	216f4459-017f-44f8-a396-c347c10aeb7e	156	submission	2026-06-29 20:37:13.866395+00	2026-07-04 15:37:13.953035+00
19402bf9-6aff-4696-9a5c-327fe0cd6614	662b71e8-b41e-4198-a07c-9fdb8288e651	1764a08c-5437-4934-8c36-4a52fe8be50f	146	submission	2026-07-03 11:37:13.866395+00	2026-07-04 15:37:13.953035+00
678bdac1-d722-4180-a7bc-6457e16eccf5	99bff3a0-8237-4afd-bd58-937faf6cbaae	f69940b2-96fa-4e98-bfbb-014af377cf43	130	submission	2026-07-04 13:37:13.866395+00	2026-07-04 15:37:13.956359+00
be4aef0c-b002-48bc-ae0d-f6d3c8273244	99bff3a0-8237-4afd-bd58-937faf6cbaae	4f1a70dd-699f-47f9-9249-4d9159ff1779	134	submission	2026-07-02 01:37:13.866395+00	2026-07-04 15:37:13.956359+00
41ff0856-42c6-44d4-a899-13d582735a0d	99bff3a0-8237-4afd-bd58-937faf6cbaae	6ced6c01-eed9-427f-a03f-15aa27cb6b28	128	submission	2026-06-26 14:37:13.866395+00	2026-07-04 15:37:13.956359+00
5f9509a7-0c8f-4220-a655-383f98f63113	b584e81c-08dd-4f1f-b181-6e02de1214b0	66a1d5b4-7907-4b3a-88ad-fb78cea62395	148	submission	2026-06-28 22:37:13.866395+00	2026-07-04 15:37:13.95938+00
ea42812d-06e4-4d6d-919d-1c23a2bffebe	b584e81c-08dd-4f1f-b181-6e02de1214b0	95b44407-9a6e-4115-b18e-3dcaf8fd54c3	162	submission	2026-07-02 02:37:13.866395+00	2026-07-04 15:37:13.95938+00
60b3e35e-ceaa-4b06-81cd-de31e1ac49b7	b584e81c-08dd-4f1f-b181-6e02de1214b0	5f4ebf45-1bfe-475c-a858-6ac668d5171f	138	submission	2026-07-01 07:37:13.866395+00	2026-07-04 15:37:13.95938+00
725cfc16-2692-41ba-b95c-574ecc2a4d13	b584e81c-08dd-4f1f-b181-6e02de1214b0	d73fb91d-6a83-4158-9356-9a49ef6447d2	130	submission	2026-06-27 04:37:13.866395+00	2026-07-04 15:37:13.95938+00
2c3093eb-cae7-418e-b2d6-ceb21e6bcf3e	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	45673d97-c4d0-4680-9bc5-665e72a7995e	142	submission	2026-07-04 12:37:13.866395+00	2026-07-04 15:37:13.974962+00
141cc53d-fe46-45c7-87d5-0870a09a9bfb	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	f61fde7d-326d-4462-a5ff-ef66df54d9e7	148	submission	2026-06-29 05:37:13.866395+00	2026-07-04 15:37:13.974962+00
e9ca6ce8-9e99-42cc-a930-e7d45521a746	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	09a5bf13-99a0-42e5-97dd-1012a92b88f6	170	submission	2026-06-28 15:37:13.866395+00	2026-07-04 15:37:13.974962+00
e9bc8f98-6475-4f2f-a6a8-c851dd2600bb	b3d8a2a1-32bb-4694-9a0f-4c2758594ec7	6e76bbb7-54ee-4662-97c6-aaabec0462b5	152	submission	2026-06-28 13:37:13.866395+00	2026-07-04 15:37:13.974962+00
9f58e418-1258-40f3-acfe-2c712595cc43	6f394335-b63b-4c72-b929-78733facb505	fede438b-b7c4-4ae1-a583-e09bf7214c41	144	submission	2026-06-26 11:37:13.866395+00	2026-07-04 15:37:13.978905+00
bd6d13d1-3d22-4088-ab6e-f840f75110d7	6f394335-b63b-4c72-b929-78733facb505	6cea0ca9-3583-429e-8102-a5a4fd364193	144	submission	2026-06-27 22:37:13.866395+00	2026-07-04 15:37:13.978905+00
3fb846cd-80ff-482d-846e-1d463cd2b26c	6f394335-b63b-4c72-b929-78733facb505	768cfd45-f415-46cb-86f0-c1e3f4d96671	166	submission	2026-06-27 01:37:13.866395+00	2026-07-04 15:37:13.978905+00
08291f3f-0f9a-4768-ab5e-bb6c1bcd8ac4	6f394335-b63b-4c72-b929-78733facb505	f94ebff4-9fb7-4883-b15a-fb25e3248cb9	142	submission	2026-06-29 23:37:13.866395+00	2026-07-04 15:37:13.978905+00
2c1e631d-2005-4a8e-910e-3cec190016b1	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	3f0f9ced-e914-42c7-af90-cbab87e325de	132	submission	2026-06-26 20:37:13.866395+00	2026-07-04 15:37:13.982684+00
fd927b8c-74e2-4dbd-987e-9eff51e504c9	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	8c667cad-e6d6-4470-8af7-04e82391ae6e	148	submission	2026-06-27 03:37:13.866395+00	2026-07-04 15:37:13.982684+00
ece3a51b-19fe-45da-b9fa-78ef0c8b07f3	9f3d5f46-21f7-4dcd-aa90-ecae17b65f0b	b9238b70-4c37-438d-a88a-aa3ec56c9b71	140	submission	2026-06-28 08:37:13.866395+00	2026-07-04 15:37:13.982684+00
5e67ff44-11ad-47cf-8f7a-fdae9711696c	1f8f0810-c92e-48f5-9bc7-eda00173e390	31a5ec23-c1e5-4c8c-a4cc-39d17b9d98ab	154	submission	2026-06-24 23:37:13.866395+00	2026-07-04 15:37:13.986006+00
a7289b51-6503-48d3-91ee-b83f05f7b64d	1f8f0810-c92e-48f5-9bc7-eda00173e390	4e5e81be-363f-481d-80b5-2430fff7a5ca	144	submission	2026-06-30 19:37:13.866395+00	2026-07-04 15:37:13.986006+00
f546c04e-c4f7-439d-bcdb-58e2ad82cee7	1f8f0810-c92e-48f5-9bc7-eda00173e390	8e4bb48a-9e44-4c18-ab58-7fe2359df794	134	submission	2026-07-01 07:37:13.866395+00	2026-07-04 15:37:13.986006+00
fcd9ed8b-948f-4f07-ac20-d2c8f41216ac	51cfb12f-6865-4891-8342-aec015a5f60c	aa72dd02-86f7-4c19-85cb-7b5cae529831	148	submission	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:13.989101+00
21e7aca3-1800-4505-ac3f-d0265c9d8119	51cfb12f-6865-4891-8342-aec015a5f60c	2f47ca19-057d-4980-b3df-1c319a8a2dab	156	submission	2026-06-25 03:37:13.866395+00	2026-07-04 15:37:13.989101+00
2a929eac-9e53-4bb4-a66c-fde0f0b91293	51cfb12f-6865-4891-8342-aec015a5f60c	40eb9350-7635-431e-ae7c-aa753f1e0e9a	148	submission	2026-06-25 22:37:13.866395+00	2026-07-04 15:37:13.989101+00
62a3b2c6-bcb0-4ac1-bee2-21af31d1f5bf	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	b23fc5ca-10ac-471e-a2cd-c51adabc7658	136	submission	2026-06-24 21:37:13.866395+00	2026-07-04 15:37:14.003592+00
82b8bfa7-f478-40c7-9763-78ea4a4c3f7a	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	66d09a8f-023b-40c5-9221-59d12805cc2c	156	submission	2026-06-29 09:37:13.866395+00	2026-07-04 15:37:14.003592+00
48fbe754-ba91-49aa-bb99-9cbdf85c757b	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	4bbe2fbb-ce58-4e74-8e36-ffde513b5ad9	158	submission	2026-07-03 00:37:13.866395+00	2026-07-04 15:37:14.003592+00
b8ec3c9a-f010-484c-9ef2-717a969f39f3	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	fb4a92cb-afa8-4657-be68-08d63ac9dd2e	130	submission	2026-06-24 14:37:13.866395+00	2026-07-04 15:37:14.003592+00
1bd24c99-d2ea-43a6-b0dc-7ec4990de38e	67e3cbb6-67b6-4750-98bd-c43809d9e5ff	0b5d5bcf-d14f-4edf-9c29-8b00533bb9de	142	submission	2026-06-24 12:37:13.866395+00	2026-07-04 15:37:14.003592+00
52e7fa5c-197d-4660-a009-4618cb005799	13b13315-eb4e-4da6-b645-e558bf78f6db	09952ee0-3b05-49ef-8db4-519bd3a4b743	152	submission	2026-07-04 06:37:13.866395+00	2026-07-04 15:37:14.008312+00
f915de47-5b1d-48a7-a3fc-5570bd5ebaed	13b13315-eb4e-4da6-b645-e558bf78f6db	9018bd1e-547c-4a3f-8199-b78b8f4404e1	152	submission	2026-06-24 08:37:13.866395+00	2026-07-04 15:37:14.008312+00
1488512f-3459-4114-985e-8b5ace029322	13b13315-eb4e-4da6-b645-e558bf78f6db	48247057-f810-48f7-8cc4-0ac3cff4b84a	132	submission	2026-07-04 04:37:13.866395+00	2026-07-04 15:37:14.008312+00
e3aa641a-ebce-4f96-bda4-2c89a5d72010	182470a9-678c-4231-bbbf-41d427773497	f36ea940-be4f-42e5-846e-419f87f21c02	162	submission	2026-06-27 11:37:13.866395+00	2026-07-04 15:37:14.011634+00
fea99e7e-e6a0-4917-821f-0f8b10f9e108	182470a9-678c-4231-bbbf-41d427773497	e10f3719-3b8f-495c-b438-b3c8859e890b	158	submission	2026-06-27 01:37:13.866395+00	2026-07-04 15:37:14.011634+00
cfe927a4-5a07-472f-bb2d-5b9d32610d10	182470a9-678c-4231-bbbf-41d427773497	419ec27e-11e0-478f-b62d-791043fd431e	148	submission	2026-06-27 08:37:13.866395+00	2026-07-04 15:37:14.011634+00
ba0b8eb7-e68c-4175-8957-bcbd7a46ea87	8f73affc-cb6c-4b19-92fc-2337385eb851	7b39b83e-43cb-440f-88df-b77b00d99a6f	130	submission	2026-06-29 20:37:13.866395+00	2026-07-04 15:37:14.014855+00
f7afc09a-45ca-4a7b-8388-775ae7d11c10	8f73affc-cb6c-4b19-92fc-2337385eb851	755eb452-2de0-4151-bff3-f279c077aea0	158	submission	2026-06-26 22:37:13.866395+00	2026-07-04 15:37:14.014855+00
944c9dad-f7b4-46a1-aeed-8eed81eb20e8	8f73affc-cb6c-4b19-92fc-2337385eb851	ed953bc7-0e32-4f29-951a-790dcae2b4a1	144	submission	2026-07-01 03:37:13.866395+00	2026-07-04 15:37:14.014855+00
c02e545f-45a5-4dfc-885a-a1209664ea18	12b3b088-bdf0-4379-b2a7-aeae73280ea6	8b6c5e05-3c6e-40fb-a086-4401c4390637	138	submission	2026-06-30 08:37:13.866395+00	2026-07-04 15:37:14.018145+00
df0e69b2-e61c-4dc8-b597-3a51740dffdf	12b3b088-bdf0-4379-b2a7-aeae73280ea6	3083ed90-1c08-43bb-8676-ba214c62916e	164	submission	2026-07-01 00:37:13.866395+00	2026-07-04 15:37:14.018145+00
c2107cb7-3a2b-4895-8cb0-3ee9a7da07fe	12b3b088-bdf0-4379-b2a7-aeae73280ea6	a690611f-b1e0-476c-95dd-914648dd1d12	130	submission	2026-06-30 08:37:13.866395+00	2026-07-04 15:37:14.018145+00
67a8f77b-d8e8-4890-81ee-f7167a9e5278	12b3b088-bdf0-4379-b2a7-aeae73280ea6	e031cbea-392d-4bb6-8053-7f178866c88c	128	submission	2026-06-30 11:37:13.866395+00	2026-07-04 15:37:14.018145+00
56fb8bef-11fa-42fd-96f2-264161186a63	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	d62885ce-cc8e-4f98-9606-438cd9443325	124	submission	2026-07-03 13:37:13.866395+00	2026-07-04 15:37:14.034497+00
3ce56670-b79a-49e9-a832-5baf85c29541	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	8dd27d45-c888-436a-b978-4695143b170c	152	submission	2026-06-30 13:37:13.866395+00	2026-07-04 15:37:14.034497+00
412d45e2-255e-47e3-a93c-85a296c5de0c	9bf54b62-e54f-47f7-b8b4-9ac54cb5878f	2b4efca5-c485-42d5-9702-46c4bec8c069	158	submission	2026-06-26 03:37:13.866395+00	2026-07-04 15:37:14.034497+00
1facb79f-2eb4-4f01-bbb4-b4582972598a	86df832e-096f-4174-b022-a932fedefca0	c16922f7-8eae-4794-8003-01b25d98ce4f	142	submission	2026-07-03 10:37:13.866395+00	2026-07-04 15:37:14.037551+00
ffb0712f-40f1-4634-8aa7-739ce24bc8ed	86df832e-096f-4174-b022-a932fedefca0	cf1d1cef-9c87-4628-8948-2d61eceeea95	136	submission	2026-07-04 08:37:13.866395+00	2026-07-04 15:37:14.037551+00
6d217f86-4b10-4c2b-83fa-1ba49b27a8b2	86df832e-096f-4174-b022-a932fedefca0	c72a58aa-bd06-474c-827c-d79c305d72f5	156	submission	2026-06-23 21:37:13.866395+00	2026-07-04 15:37:14.037551+00
63c43c14-c50e-4a4b-a230-f8f7297e8a78	2715a5ba-2133-4fe9-af71-83c274e65cbc	fef4d6f8-f062-4f15-8c37-9f34897d1255	138	submission	2026-06-24 21:37:13.866395+00	2026-07-04 15:37:14.040815+00
b606d419-f4af-49d1-ae6e-168d0481e50e	2715a5ba-2133-4fe9-af71-83c274e65cbc	a4541fb8-3afe-4450-a8db-0f3ceac92429	162	submission	2026-06-26 00:37:13.866395+00	2026-07-04 15:37:14.040815+00
66166006-d03e-456b-8e27-2f1dade51e65	2715a5ba-2133-4fe9-af71-83c274e65cbc	5d986e15-5051-4878-a4a4-3cddbda19f39	150	submission	2026-06-30 21:37:13.866395+00	2026-07-04 15:37:14.040815+00
843b5f3b-eeaf-4e4f-8e62-001c093e29ec	8149a2f8-99af-4e89-a11e-89fb61297ef1	663ebcec-4836-4b45-98af-f9fff4b7feef	130	submission	2026-06-25 02:37:13.866395+00	2026-07-04 15:37:14.04458+00
a869fd20-1dab-4df8-93d5-1a6d941a0e68	8149a2f8-99af-4e89-a11e-89fb61297ef1	0562f646-5808-4135-a753-4b75cee4c572	152	submission	2026-07-02 05:37:13.866395+00	2026-07-04 15:37:14.04458+00
fd0e5838-026a-4487-8724-9de0872b4dbf	8149a2f8-99af-4e89-a11e-89fb61297ef1	d1a855a9-40e8-41b7-82ee-54d09533864c	158	submission	2026-07-03 05:37:13.866395+00	2026-07-04 15:37:14.04458+00
cf3f5e82-8c32-4d00-b8be-c1debfc2695f	8149a2f8-99af-4e89-a11e-89fb61297ef1	e5994e27-be8a-4845-ab4f-2b5a572eb3af	144	submission	2026-06-26 01:37:13.866395+00	2026-07-04 15:37:14.04458+00
556a13dc-21ae-4dcf-a12d-750cd75f2880	85a2e644-0cee-439c-88fb-590ea4128006	93304d73-fbcc-42bc-8307-e5503b13b3f7	154	submission	2026-06-27 12:37:13.866395+00	2026-07-04 15:37:14.049113+00
50e6bbbd-b390-4a9e-8500-6591702ec8fb	85a2e644-0cee-439c-88fb-590ea4128006	bf818566-9785-4f3f-a8d9-07d8e36f5ce5	156	submission	2026-06-28 13:37:13.866395+00	2026-07-04 15:37:14.049113+00
3d588d11-499e-4137-8597-50b96dd4a722	85a2e644-0cee-439c-88fb-590ea4128006	42920bf0-86de-4946-955d-4ebf2c021e6d	142	submission	2026-06-29 23:37:13.866395+00	2026-07-04 15:37:14.049113+00
91308879-5a92-4733-849c-e2bf88a34e77	85a2e644-0cee-439c-88fb-590ea4128006	6fe0ce58-4e1e-43f7-aa39-7d5620976a3f	162	submission	2026-06-30 20:37:13.866395+00	2026-07-04 15:37:14.049113+00
b52e9e0c-072e-4b22-813b-3e44022bfb18	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	11ff5003-d2b8-4b46-8252-0641f27e061c	0	submission	2026-07-09 05:25:45.322233+00	2026-07-09 05:25:45.322233+00
16b484a9-3161-4454-902a-74f5386229f6	f72d332d-3ca0-425e-8ca1-0b5ff7a5e30c	11ff5003-d2b8-4b46-8252-0641f27e061c	0	submission	2026-07-09 05:39:09.429353+00	2026-07-09 05:39:09.429353+00
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_submission_id_key; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_submission_id_key UNIQUE (submission_id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: question_blocks question_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.question_blocks
    ADD CONSTRAINT question_blocks_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: review_items review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_pkey PRIMARY KEY (id);


--
-- Name: shadowing_phrases shadowing_phrases_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.shadowing_phrases
    ADD CONSTRAINT shadowing_phrases_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: topic_images topic_images_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.topic_images
    ADD CONSTRAINT topic_images_pkey PRIMARY KEY (id);


--
-- Name: topics topics_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT topics_pkey PRIMARY KEY (id);


--
-- Name: transcripts transcripts_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.transcripts
    ADD CONSTRAINT transcripts_pkey PRIMARY KEY (id);


--
-- Name: transcripts transcripts_submission_id_key; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.transcripts
    ADD CONSTRAINT transcripts_submission_id_key UNIQUE (submission_id);


--
-- Name: group_members uq_group_member; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT uq_group_member UNIQUE (group_id, student_id);


--
-- Name: groups uq_groups_join_code; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT uq_groups_join_code UNIQUE (join_code);


--
-- Name: topics uq_topic_teacher_name; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT uq_topic_teacher_name UNIQUE (teacher_id, name);


--
-- Name: users uq_users_google_sub; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_google_sub UNIQUE (google_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: xp_events xp_events_pkey; Type: CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.xp_events
    ADD CONSTRAINT xp_events_pkey PRIMARY KEY (id);


--
-- Name: ix_assignments_group_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_assignments_group_id ON public.assignments USING btree (group_id);


--
-- Name: ix_assignments_question_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_assignments_question_id ON public.assignments USING btree (question_id);


--
-- Name: ix_assignments_student_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_assignments_student_id ON public.assignments USING btree (student_id);


--
-- Name: ix_assignments_teacher_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_assignments_teacher_id ON public.assignments USING btree (teacher_id);


--
-- Name: ix_group_members_group_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_group_members_group_id ON public.group_members USING btree (group_id);


--
-- Name: ix_group_members_student_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_group_members_student_id ON public.group_members USING btree (student_id);


--
-- Name: ix_groups_teacher_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_groups_teacher_id ON public.groups USING btree (teacher_id);


--
-- Name: ix_notifications_is_read; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_question_blocks_teacher_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_question_blocks_teacher_id ON public.question_blocks USING btree (teacher_id);


--
-- Name: ix_question_blocks_visibility; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_question_blocks_visibility ON public.question_blocks USING btree (visibility);


--
-- Name: ix_questions_block_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_block_id ON public.questions USING btree (block_id);


--
-- Name: ix_questions_is_public; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_is_public ON public.questions USING btree (is_public);


--
-- Name: ix_questions_level; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_level ON public.questions USING btree (level);


--
-- Name: ix_questions_ru_style; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_ru_style ON public.questions USING btree (ru_style);


--
-- Name: ix_questions_teacher_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_teacher_id ON public.questions USING btree (teacher_id);


--
-- Name: ix_questions_topic; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_topic ON public.questions USING btree (topic);


--
-- Name: ix_questions_type; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_questions_type ON public.questions USING btree (type);


--
-- Name: ix_review_items_completed; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_review_items_completed ON public.review_items USING btree (completed);


--
-- Name: ix_review_items_due_at; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_review_items_due_at ON public.review_items USING btree (due_at);


--
-- Name: ix_review_items_question_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_review_items_question_id ON public.review_items USING btree (question_id);


--
-- Name: ix_review_items_student_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_review_items_student_id ON public.review_items USING btree (student_id);


--
-- Name: ix_shadowing_phrases_created_by; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_shadowing_phrases_created_by ON public.shadowing_phrases USING btree (created_by);


--
-- Name: ix_shadowing_phrases_is_active; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_shadowing_phrases_is_active ON public.shadowing_phrases USING btree (is_active);


--
-- Name: ix_submissions_assignment_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_submissions_assignment_id ON public.submissions USING btree (assignment_id);


--
-- Name: ix_submissions_question_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_submissions_question_id ON public.submissions USING btree (question_id);


--
-- Name: ix_submissions_status; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_submissions_status ON public.submissions USING btree (status);


--
-- Name: ix_submissions_student_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_submissions_student_id ON public.submissions USING btree (student_id);


--
-- Name: ix_topic_images_topic_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_topic_images_topic_id ON public.topic_images USING btree (topic_id);


--
-- Name: ix_topics_teacher_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_topics_teacher_id ON public.topics USING btree (teacher_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_xp_events_student_id; Type: INDEX; Schema: public; Owner: russpeak
--

CREATE INDEX ix_xp_events_student_id ON public.xp_events USING btree (student_id);


--
-- Name: assignments assignments_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: assignments assignments_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: assignments assignments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assignments assignments_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: evaluations evaluations_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(id) ON DELETE CASCADE;


--
-- Name: questions fk_questions_block_id; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT fk_questions_block_id FOREIGN KEY (block_id) REFERENCES public.question_blocks(id) ON DELETE SET NULL;


--
-- Name: submissions fk_submissions_assignment_id; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk_submissions_assignment_id FOREIGN KEY (assignment_id) REFERENCES public.assignments(id) ON DELETE SET NULL;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: question_blocks question_blocks_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.question_blocks
    ADD CONSTRAINT question_blocks_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: questions questions_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: review_items review_items_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.review_items
    ADD CONSTRAINT review_items_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shadowing_phrases shadowing_phrases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.shadowing_phrases
    ADD CONSTRAINT shadowing_phrases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: submissions submissions_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: submissions submissions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: topic_images topic_images_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.topic_images
    ADD CONSTRAINT topic_images_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(id) ON DELETE CASCADE;


--
-- Name: topics topics_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT topics_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transcripts transcripts_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.transcripts
    ADD CONSTRAINT transcripts_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(id) ON DELETE CASCADE;


--
-- Name: xp_events xp_events_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.xp_events
    ADD CONSTRAINT xp_events_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: xp_events xp_events_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: russpeak
--

ALTER TABLE ONLY public.xp_events
    ADD CONSTRAINT xp_events_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.submissions(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: russpeak
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict CGvNjIQbSKd1ViCkCRikDUO9ziUziRoUvz8kauZ6Z11Bhnexw6E9K0gSgcgIMLk

